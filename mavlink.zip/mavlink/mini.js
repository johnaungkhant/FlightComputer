var compressor = require('node-minify');

function min(input, output, cb) {
  console.log('start mining', input, output);

  // Using Google Closure Compiler
  compressor.minify({
    compressor: 'terser',
    input: input,
    output: output,
    callback: function (err, min) {
      console.log('finish mining', input, output);
      if (cb) cb()
    }
  });

}

var allCompFiles = [
  // "./app.js",
  // "./cpMvLink.js",
  // "./NwDataMsgObj.js",
  // "./NwServiceMethod.js",
  // "./NwServiceProcess.js",
  // "./NwWsServer.js",
  // "./driver/SystemConfig.js",
  // "./driver/SystemResCheck.js",
  // "./driver/usbCDCProcess.js",
  // "./lib/NwLib.js",
  // "./lib/Nwjsface.js",
  // "./service/autoMount.js",
  //"./web/index.html"
]

for (let index = 0; index < allCompFiles.length; index++) {
  const fileName = allCompFiles[index];
  min(fileName, fileName)
}

// min("./server.js", "./server.mini.js")
// for (let index = 0; index < allCompFiles.length; index++) {
//   const fileName = allCompFiles[index];
//   min(fileName,fileName.replace(".js",".mini.js"))
// }

// min( './hello.js', './min/hello.min.js')
// min( './mini.js', './min/mini.min.js')

// // Using UglifyJS with wildcards
// compressor.minify({
//   compressor: 'uglifyjs',
//   input: './**/*.js',
//   output: 'bar.js',
//   callback: function(err, min) {}
// });
 
// // With Promise
// var promise = compressor.minify({
//   compressor: 'uglifyjs',
//   input: './**/*.js',
//   output: 'bar.js'
// });
 
// promise.then(function(min) {});