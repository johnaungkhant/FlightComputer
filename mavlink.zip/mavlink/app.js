
let _ = require("underscore");
let async = require("async");
const Backbone = require("backbone");

let mvLink = null

const SystemConfig = require("./driver/SystemConfig.js");
const RateList = require("./driver/RateList.js");

const SystemResCheck = require("./driver/SystemResCheck.js");


async.series([
    function (callback) {

        //require('node-cmd').run("echo gadget  > /sys/kernel/debug/usb/ci_hdrc.0/role");
        require('node-cmd').run("echo host > /sys/kernel/debug/usb/ci_hdrc.0/role");
        //require('node-cmd').run("sudo usb_modeswitch -v 0x1d6b -p 0x0002 --reset-usb");

        setTimeout(function () {
            // do some async task
            callback(null, 'usb');
        }, 2000);
    },
    function (callback) {

        require('./service/autoMount.js')

        //mvLink = require('./usbMvLink.js')
        //const mvLink = require('./NwMvLink.js')
        mvLink = require('./cpMvLink.js')

        setTimeout(function () {
            // then do another async task
            callback(null, 'mavlink');
        }, 1000);
    },
    function (callback) {
        mvLink.RequestDataStream(true)

        setTimeout(function () {
            // then do another async task
            callback(null, 'RequestDataStream');
        }, 1000);
    },
    function (callback) {
        let http = require('http');
        let nodeStatic = require('node-static');
        let path = require('path');
        let file = new nodeStatic.Server(path.resolve(__dirname + '/web'));

        let mapDataPath = '/data'
        if (process.platform == 'win32') {
            mapDataPath = 'D:\\'
        }

        let fileMapData = new nodeStatic.Server(path.resolve('/data'));

        let NwLib = require('./lib/NwLib.js');
        let Class = NwLib.Nwjsface.Class;

        // nwHttpConn = require('./nwHttpConn.js');

        let NwWsServer = require('./NwWsServer.js');
        let NwServiceProcess = require('./NwServiceProcess.js');
        let NwServiceMethod = require('./NwServiceMethod.js');

        //------------------------------------------------------------------------

        //let NwWsClient = require('./web/NwWsClient.js');

        // // wsClient = new NwWsClient("http://newww.duckdns.org");
        // wsClient = new NwWsClient("http://rutapon.totddns.com:37900");
        // // wsClient = new NwWsClient("http://newwwnode.herokuapp.com");
        // //wsClient = new NwWsClient("http://autovs.herokuapp.com");
        // //wsClient = new NwWsClient("http://192.168.43.1");
        // deviceId = null
        // require('systeminformation').blockDevices(function (data) {
        //     deviceId = data[0].serial;

        //     deviceId = require('crypto').createHash('sha256').update(deviceId + "'").digest('base64url')
        //     console.log(deviceId);
        // })

        // wsClient.setOnConnectEventListener(function (socket) {
        //     var id = wsClient.getId();
        //     console.log('onConnect setOnConnectEventListener' + id);

        //     wsClient.callService('reg_node', { sid: id, did: deviceId }, function (resultData) {
        //         console.log('resultData', resultData);
        //         // cb(resultData)
        //     });

        //     // wsClient.callService('getServerDateTime', null, function (result) {
        //     //     console.log(result);
        //     // })
        // });

        // wsClient.setOnMessageEventListener(function (socket, msgObj, fn) {
        //     // console.log('OnMessage', msgObj, wsClient.getId());

        //     NwServiceProcess.cammandProcess(msgObj, function (result) {
        //         //console.log(result);
        //         fn(result);
        //     });
        // })

        // wsClient.setOnDisconnectEventListener(function () {
        //     console.log('wsClient Disconnect');
        // });

        //------------------------------------------------------------------------

        var port = 80
        var httpConn = null;
        var espColl = null;

        var wsServer = null;

        let led = require('./driver/OnbordLed.js')
        led.blink(1000)

        var passiveConn = function (appServer, httpConn, espColl) {
            var self = this;

            wsServer = new NwWsServer(appServer);

            NwServiceMethod.addNwWsServer(wsServer, httpConn, espColl);

            NwServiceProcess.addServiceMethod(NwServiceMethod);

            wsServer.setOnConnectEventListener(function (socket) {
                console.log('OnConnectEventListener ' + socket.id);
                //led.stop()
                led.blink(100)
                //withoutRemote = true
            });

            wsServer.setOnDisconnectEventListener(function (socket) {
                console.log('OnDisconnectEventListener');
                led.blink(1000)
            });

            wsServer.setOnMessageEventListener(function (socket, msgObj, fn) {
                NwServiceProcess.cammandProcess(msgObj, function (result) {
                    //console.log(result);
                    fn(result);
                });
            });
        }

        var listenCommand = function (commandPort) {
            this.commandPort = commandPort;

            //var httpServer = http.createServer(app);
            var appServer = http.createServer(function (request, response) {
                //console.log(request.method, request.url);
                request.addListener('end', function () {

                    if (objectData.timeUnixUsec && SystemResCheck.expireDateCheck(objectData.timeUnixUsec.toISOString())) {
                        response.end("System is Expire!!!\nCurrent ISO Date/Time: " + objectData.timeUnixUsec.toISOString())
                    } else {
                        //
                        // Serve files
                        //
                        if (request.method == 'GET' && request.url.indexOf('/MapData/') == 0) {
                            //console.log('mapdata');
                            fileMapData.serve(request, response);
                        }
                        else if (request.method == 'GET' && request.url.indexOf('/MTD?') == 0) {
                            //console.log('serv');
                            //fileMapData.serve(request, response);
                            let dataStr = request.url.split('?')[1]
                            //console.log(dataStr);
                            if (dataStr != '') {
                                var dataObj = JSON.parse(dataStr)
                                let method = NwServiceProcess.cmdMethod[dataObj.mtd]
                                method(dataObj.param, function (result) {
                                    response.end(JSON.stringify(result))

                                })
                            } else {
                                let method = NwServiceProcess.cmdMethod['getInfo']
                                method(null, function (result) {
                                    response.end(JSON.stringify(result))

                                })
                            }
                        }
                        else {
                            file.serve(request, response);
                        }
                    }
                }).resume();
            });

            passiveConn(appServer, httpConn, espColl);

            appServer.listen(commandPort);
        }

        listenCommand(port);

        console.log('Start App newww');

        ///end network setup
        //===================================================================================

        const customModeMap = {
            0: "Stabilize",
            1: "Acro",
            2: "AltHold",
            3: "Auto",
            4: "Guided",
            5: "Loiter",
            6: "RTL",
            7: "Circle",
            9: "Land",
            11: "Drift",
            13: "Sport",
            14: "Flip",
            15: "AutoTune",
            16: "PosHold",
            17: "Brake",
            18: "Throw",
            19: "Avoid_ADSB",
            20: "Guided_NoGPS",
            21: "Smart_RTL",
            22: "FlowHold",
            23: "Follow",
            24: "ZigZag",
            25: "SystemID",
            26: "Heli_Autorotate",
            27: "Auto RTL",
        }

        let mode_state = 'disarming'
        let objectData = {
            // posInt: {
            //     lat: 86970325, lon: 982410939
            // }
        }
        objectData.seq = mvLink.get('seq')

        objectData.customMode = mvLink.get('customMode')
        objectData.customMode = customModeMap[objectData.customMode]

        objectData.hdop = mvLink.get('hdop')
        objectData.posInt = mvLink.get('posInt')
        if (objectData.posInt && objectData.posInt.lat != 0 && objectData.posInt.lon != 0) {
            objectData.ctCode = SystemResCheck.checkReg(objectData.posInt.lat, objectData.posInt.lon)
        }

        objectData.posRawInt = mvLink.get('posRawInt')

        objectData.alt = mvLink.get('alt')

        mvLink.on('change', function (event) {
            //console.log(event.changed);
            for (const key in event.changed) {
                if (Object.hasOwnProperty.call(event.changed, key)) {
                    let value = event.changed[key];
                    if (key == 'customMode') {
                        value = customModeMap[value]
                        objectData.customMode = value
                        console.log('change', key, value);
                        if (value == 'Loiter') {
                            RcChannelsOverride(throttleCh, 1500)
                        }
                    }
                    else if (key == 'baseMode') {
                        console.log('baseMode', key, value);
                        if (value == '81') {//magic number for apm2.5
                            mode_state = 'disarming'
                        }
                        console.log('change', key, value);
                    }
                    else if (key == 'hdop') {
                        objectData.hdop = value
                        ///console.log('change', key, value);
                    }
                    else if (key == 'posInt') {
                        //console.log('posInt', value);
                        if (value.lat == 0 && value.lon == 0) {
                            //no gps data
                        }
                        // else if (objectData.hdop < 300) {
                        //     //console.log('change', key, value);
                        //     objectData.posInt = value
                        // } 
                        else {
                            objectData.posInt = value
                            objectData.ctCode = SystemResCheck.checkReg(objectData.posInt.lat / 1e7, objectData.posInt.lon / 1e7)
                        }
                    }

                    else if (key == 'posRawInt') {
                        //console.log('posRawInt', value);
                        if (value.lat == 0 && value.lon == 0) {
                            //no gps data
                        }
                        // else if (objectData.hdop < 300) {
                        //     //console.log('change', key, value);
                        //     objectData.posRawInt = value
                        // }
                        else {
                            objectData.posRawInt = value
                        }
                    }
                    else if (key == 'heading') {
                        //console.log('change', key, value);
                        objectData.heading = value
                    }
                    // else if (key == 'servo8Raw') {
                    //     console.log('change', key, value);
                    // }
                    // else if (key == 'timeUsec') {
                    //     // let gpsTime = new Date()
                    //     // gpsTime.setMilliseconds(Number(value))
                    //     // console.log('change', key, Number(value));
                    //     // objectData.timeUsec = new Date(Number(value))
                    // }
                    else if (key == 'wpDist') {
                        //console.log('change', key, value);
                        objectData.wpDist = value
                    }
                    else if (key == 'seq') {
                        console.log('change', key, value);
                        objectData.seq = value
                    }
                    // else if (key == 'missionState') {
                    //     //console.log('change', key, value);
                    //     objectData.missionState = value
                    // }
                    else if (key == 'timeUnixUsec') {
                        //console.log('change', key, new Date(Number(value) / 1000));
                        if (objectData.timeUnixUsec == null) {
                            console.log('start at', new Date(Number(value) / 1000));
                        }
                        objectData.timeUnixUsec = new Date(Number(value) / 1000)

                        //console.log(objectData.timeUnixUsec.toISOString(), SystemResCheck.expireDateCheck(objectData.timeUnixUsec.toISOString()));
                    }
                    else if (key == 'voltageBattery') {
                        //console.log('change', key, new Date(Number(value) / 1000));
                        objectData.voltageBattery = value / 1000
                    }
                    else if (key == 'currentBattery') {
                        //console.log('change', key, new Date(Number(value) / 1000));
                        objectData.currentBattery = value
                    }
                    else if (key == 'batteryRemaining') {
                        //console.log('change', key, new Date(Number(value) / 1000));
                        objectData.batteryRemaining = value
                    }
                    else if (key == 'alt') {
                        objectData.alt = value //absolute 
                    }
                    else if (key == 'relativeAlt') {
                        objectData.relativeAlt = value
                    } else if (key == 'chan2Raw') {
                        chan2Raw(value)
                    }
                    else {
                        //console.log('change', key, value);
                    }

                }
            }
        })

        let droneState = new Backbone.Model()
        droneState.set('gpsConnection', 'start')

        let lastHdop = null
        const hdopWorking = 230
        const hdopJamming = 330
        let outOffJammingCount = 0
        const outOffJammingNumber = 3

        let workingTimeoutHandle = null

        mvLink.on('change:hdop', function (obj, value) {
            let diff = value - lastHdop
            let lastGpsConnectionState = droneState.get('gpsConnection')

            // if (lastHdop !== null) {
            //     console.log(value, diff);
            // } else {
            //     console.log(value);
            // }

            if (lastGpsConnectionState == 'start') {
                // in start
                if (value < hdopWorking) {
                    droneState.set('gpsConnection', 'working')
                }

            } else {

                if (value > hdopJamming) {
                    //jamming case
                    console.log('detect jamming', value, diff, objectData.timeUnixUsec);
                    droneState.set('gpsConnection', 'jamming')
                    outOffJammingCount = 0
                } else {
                    if (diff > 80) {
                        console.log('posible jamming', value, diff);
                    }
                    if (lastGpsConnectionState == 'working') {
                        if (value > hdopWorking) {
                            console.log('detect low', value, diff, objectData.timeUnixUsec);
                            droneState.set('gpsConnection', 'low')
                        }
                    } else if (lastGpsConnectionState == 'low') {
                        if (value < hdopWorking) {
                            droneState.set('gpsConnection', 'working')
                        }
                    } else { //lastGpsConnectionState == 'jamming'
                        if (value < hdopWorking) {//or hdopJamming
                            outOffJammingCount++
                            console.log('out of jamming count', outOffJammingCount, value, diff);

                            if (outOffJammingCount > outOffJammingNumber) {
                                console.log('out of jamming', value, diff);

                                droneState.set('gpsConnection', 'working')
                                outOffJammingCount = 0

                                if (workingTimeoutHandle != null) {
                                    clearTimeout(workingTimeoutHandle)
                                    workingTimeoutHandle = null
                                }
                            }

                            if (workingTimeoutHandle == null) {

                                workingTimeoutHandle = setTimeout(() => {
                                    console.log('out of jamming timeout', value, diff);

                                    if (value < hdopWorking) {
                                        droneState.set('gpsConnection', 'working')
                                    }
                                    else {
                                        console.log('something wrong');
                                    }
                                    outOffJammingCount = 0
                                    workingTimeoutHandle = null
                                }, 3000);
                            }
                        } else {
                            console.log('reset jamming count', outOffJammingCount, value, diff);
                            outOffJammingCount = 0
                            if (workingTimeoutHandle != null) {
                                clearTimeout(workingTimeoutHandle)
                                workingTimeoutHandle = null
                            }
                        }
                    }
                }
            }

            lastHdop = value
        })

        function jammingCallback(cb) {
            let gpsConnectionState = droneState.get('gpsConnection')

            if (gpsConnectionState == 'jamming') {
                if (cb) cb()
                return null
            } else {
                let gpsConnectionChangeEvent = function (obj, value) {
                    //console.log(value);
                    if (value == 'jamming') {
                        droneState.off('change:gpsConnection', gpsConnectionChangeEvent)
                        if (cb) cb()
                    }
                }
                droneState.on('change:gpsConnection', gpsConnectionChangeEvent)
                return gpsConnectionChangeEvent
            }
        }

        function gpsWorkingCallback(cb) {
            let gpsConnectionState = droneState.get('gpsConnection')

            if (gpsConnectionState == 'working') {
                if (cb) cb()
                return null
            } else {
                let gpsConnectionChangeEvent = function (obj, value) {
                    //console.log(value);
                    if (value == 'working') {
                        droneState.off('change:gpsConnection', gpsConnectionChangeEvent)
                        if (cb) cb()
                    }
                }

                let cancelCallback = function () {
                    cb = null
                    droneState.off('change:gpsConnection', gpsConnectionChangeEvent)
                }
                droneState.on('change:gpsConnection', gpsConnectionChangeEvent)

                return cancelCallback
            }
        }

        // jammingCallback(function () {
        //     console.log('jammingCallback');
        //     gpsWorkingCallback(function () {
        //         console.log('gpsWorkingCallback');
        //     })
        // })


        // mvLink.on('change:servo8Raw', function (self, val) {
        //     console.log(self, val);
        // })

        let gsmSignal = null;

        function getGsmSignalQuery(sid, cb) {

            let postStrUrl = "http://192.168.100.1/api/json"

            require('request').post({
                url: postStrUrl,
                "headers": {
                    "accept": "application/json, text/plain, */*",
                    "accept-language": "en,en-US;q=0.9,th;q=0.8,zh-CN;q=0.7,zh;q=0.6",
                    "authorization": "54ad2aa0-7238-42c6-90fc-6a4fd8b4eb00",
                    "content-type": "application/json;charset=UTF-8",
                    "cookie": "size=default; sidebarStatus=0",
                    "Referer": "http://192.168.100.1/",
                    "Referrer-Policy": "strict-origin-when-cross-origin"
                },
                "body": "{\"fid\":\"queryFields\",\"fields\":{\"signalStrength\":-200},\"sessionId\":\"" + sid + "\"}",

            }, function (err, httpResponse, body) {
                //console.log(JSON.parse(body).data.signal);
                // cb(JSON.parse(body).data.signal)
                // console.log(err);
                cb(body)
            });

        }

        function getGsmSignalLogin(cb) {

            let postStrUrl = "http://192.168.100.1/api/json"

            require('request').post({
                url: postStrUrl,
                "headers": {
                    "accept": "application/json, text/plain, */*",
                    "accept-language": "en,en-US;q=0.9,th;q=0.8,zh-CN;q=0.7,zh;q=0.6",
                    "authorization": "",
                    "content-type": "application/json;charset=UTF-8",
                    "cookie": "size=default; sidebarStatus=0",
                    "Referer": "http://192.168.100.1/",
                    "Referrer-Policy": "strict-origin-when-cross-origin"
                },
                "body": "{\"fid\":\"login\",\"username\":\"\",\"password\":\"123456789#a\",\"sessionId\":\"\"}",

            }, function (err, httpResponse, body) {
                //console.log(JSON.parse(body).data.signal);
                // cb(JSON.parse(body).data.signal)
                // console.log(httpResponse);
                cb(body)
            });

        }

        function getGsmSignal(cb) {
            getGsmSignalLogin(function (body) {
                // console.log(JSON.(body).session);
                if (body)
                    getGsmSignalQuery(JSON.parse(body).session, function (result) {
                        if (result)
                            cb(JSON.parse(result).fields.signalStrength)
                        else
                            cb(null)
                    })
                else {
                    cb(null)
                }
            })
        }

        var getSignalRecur = function () {
            getGsmSignal(function (result) {
                // console.log(result);
                gsmSignal = result;
                setTimeout(getSignalRecur, 1500);
            })
        }

        //getSignalRecur()

        NwServiceProcess.cmdMethod['getSystemConfig'] = function (data, cb) {
            cb(SystemConfig)
        }

        NwServiceProcess.cmdMethod['setSystemConfig'] = function (data, cb) {
            console.log('setSystemConfig', data);
            SystemConfig.set(data)
            //SystemConfig.save()
            cb('ok')
        }

        NwServiceProcess.cmdMethod['getInfo'] = function (data, cb) {
            //console.log('getInfo',objectData.timeUnixUsec);
            cb({
                data: objectData,
                now: new Date(),
                state: mode_state,
                gpsState: droneState.get('gpsConnection')
            })
        }

        // setInterval(() => {
        //     wsServer.io.emit('test', new Date())
        // }, 5000);

        NwServiceProcess.cmdMethod['arming'] = function (data, cb) {
            if (data) {
                mvLink.SetMode(0, function () {
                    mvLink.Arming(true, function () {
                        if (cb) cb(data)
                    })

                })
            } else {

                RcChannelsOverride(throttleCh, 900)
                setTimeout(() => {
                    mvLink.Arming(false)
                }, 100);

                // mvLink.doSetServo(throttleGeneratePin, 900, function () {
                //     mvLink.Arming(false)
                // })
            }
        }

        NwServiceProcess.cmdMethod['arming_only'] = function (data, cb) {
            if (data) {
                mvLink.Arming(true, function () {
                    if (cb) cb(data)
                })
            } else {

                RcChannelsOverride(throttleCh, 900)
                setTimeout(() => {
                    mvLink.Arming(false)
                }, 100);

                // mvLink.doSetServo(throttleGeneratePin, 900, function () {
                //     mvLink.Arming(false)
                // })
            }
        }

        NwServiceProcess.cmdMethod['getAllMission'] = function (undefined, cb) {
            console.log('getAllMission');
            mvLink.getAllMission(function (wp) {
                //console.log(wp);
                cb(wp)
            })
        }

        NwServiceProcess.cmdMethod['getLastMission'] = function (undefined, cb) {
            console.log('getLastMission');
            if (lastMission) {
                cb(lastMission)
            } else {
                cb(false)
            }

        }

        NwServiceProcess.cmdMethod['setMission'] = function (data, cb) {
            console.log('setMission', data);
            //get value from config
            let flyAlt = SystemConfig.get('alt_flight')
            let takeoffAlt = SystemConfig.get('alt_flight')//same as flight altitude
            let dropAlt = SystemConfig.get('alt_drop')

            let flightSpeed = SystemConfig.get('speed_ground')
            // let takeoffSpeed = SystemConfig.get('speed_takeoff')
            // let droppingSpeed = SystemConfig.get('speed_dropping')
            // let flyoutSpeed = SystemConfig.get('speed_flyout')
            // let landingSpeed = SystemConfig.get('speed_landing')


            let moveServo = SystemConfig.get('servo_max')

            mvLink.addWaypoint([
                { cmd: 16, lat: data[0].lat, lon: data[0].lon, alt: 0, frame: 3 },//home
                { cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 0, param2: flightSpeed } },//set Ground speed m/s
                //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: takeoffSpeed } },//set Climb Speed for takeoff m/s
                { cmd: 22, lat: 0, lon: 0, alt: takeoffAlt, frame: 3 },//takeOff
                { cmd: 16, lat: data[1].lat, lon: data[1].lon, alt: flyAlt, frame: 3 },//wayPoint
                { cmd: 16, lat: data[2].lat, lon: data[2].lon, alt: flyAlt, frame: 3, params: { param1: 1 } },//target and wait for 1s
                //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 3, param2: droppingSpeed } },//set Descent Speed for dropping  m/s
                //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: flyoutSpeed } },//set Climb Speed for flyout m/s
                { cmd: 16, lat: data[2].lat, lon: data[2].lon, alt: dropAlt, frame: 3 },//move down to drop
                { cmd: 183, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: servoPin, param2: moveServo } },//move servo
                { cmd: 16, lat: data[2].lat, lon: data[2].lon, alt: flyAlt, frame: 3 },//move to fry
                { cmd: 16, lat: data[3].lat, lon: data[3].lon, alt: flyAlt, frame: 3 },//wayPoint2
                //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 3, param2: landingSpeed } },//set Descent Speed for landing  m/s
                { cmd: 16, lat: data[4].lat, lon: data[4].lon, alt: flyAlt, frame: 3, params: { param1: 1 } },//wayPoint end and wait for 1s
                { cmd: 21, lat: data[4].lat, lon: data[4].lon, alt: 1, frame: 3 },//landing
            ], function (result) {
                if (cb) cb(result)
            })
            // mvLink.getAllMission(function (wp) {
            //     cb(wp)
            // })
        }

        // NwServiceProcess.cmdMethod['setMission_DynPoints'] = function (data, cb) {
        //     console.log('setMission', data);
        //     //get value from config
        //     let flyAlt = SystemConfig.get('alt_flight')
        //     let takeoffAlt = SystemConfig.get('alt_flight')//same as flight altitude
        //     let dropAlt = SystemConfig.get('alt_drop')

        //     let flightSpeed = SystemConfig.get('speed_ground')
        //     // let takeoffSpeed = SystemConfig.get('speed_takeoff')
        //     // let droppingSpeed = SystemConfig.get('speed_dropping')
        //     // let flyoutSpeed = SystemConfig.get('speed_flyout')
        //     // let landingSpeed = SystemConfig.get('speed_landing')

        //     let gotoPoints = SystemConfig.get('goto_points')
        //     let returnPoints = SystemConfig.get('return_points')
        //     let delayStartTime = SystemConfig.get('delay_start_time')

        //     let moveServo = SystemConfig.get('servo_max')

        //     let missionList = []
        //     //home
        //     missionList.push({ cmd: 16, lat: data[0].lat, lon: data[0].lon, alt: 0, frame: 3 })
        //     //set Ground speed m/s
        //     missionList.push({ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 0, param2: flightSpeed } })
        //     //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: takeoffSpeed } },//set Climb Speed for takeoff m/s

        //     //takeOff
        //     missionList.push({ cmd: 22, lat: 0, lon: 0, alt: takeoffAlt, frame: 3 })

        //     //wayPoint
        //     if (gotoPoints > 0) {
        //         for (let index = 0; index < gotoPoints; index++) {
        //             // let wayPointIndex = 1 + index
        //             missionList.push({ cmd: 16, lat: data[index].lat, lon: data[index].lon, alt: flyAlt, frame: 3 })
        //         }

        //     }

        //     let targetPos = data[gotoPoints + 1]
        //     //target and wait for 1s
        //     missionList.push({ cmd: 16, lat: targetPos.lat, lon: targetPos.lon, alt: flyAlt, frame: 3, params: { param1: 1 } })
        //     //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 3, param2: droppingSpeed } },//set Descent Speed for dropping  m/s
        //     //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: flyoutSpeed } },//set Climb Speed for flyout m/s

        //     //move down to drop
        //     missionList.push({ cmd: 16, lat: targetPos.lat, lon: targetPos.lon, alt: dropAlt, frame: 3 })
        //     //move servo
        //     missionList.push({ cmd: 183, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: servoPin, param2: moveServo } })
        //     //move to fry
        //     missionList.push({ cmd: 16, lat: targetPos.lat, lon: targetPos.lon, alt: flyAlt, frame: 3 })

        //     //wayPoint2
        //     if (returnPoints > 0) {
        //         for (let index = 0; index < returnPoints; index++) {
        //             let wayPointIndex = gotoPoints + 1 + index
        //             missionList.push({ cmd: 16, lat: data[wayPointIndex].lat, lon: data[wayPointIndex].lon, alt: flyAlt, frame: 3 })
        //         }

        //     }

        //     //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 3, param2: landingSpeed } },//set Descent Speed for landing  m/s

        //     let returnPos = data[gotoPoints + 1 + returnPoints + 1]
        //     //wayPoint end and wait for 1s
        //     missionList.push({ cmd: 16, lat: returnPos.lat, lon: returnPos.lon, alt: flyAlt, frame: 3, params: { param1: 1 } })
        //     //landing
        //     missionList.push({ cmd: 21, lat: returnPos.lat, lon: returnPos.lon, alt: 1, frame: 3 })

        //     mvLink.addWaypoint(missionList, function (result) {
        //         if (cb) cb(result)
        //     })
        //     // mvLink.getAllMission(function (wp) {
        //     //     cb(wp)
        //     // })
        // }

        let lastMission = null
        NwServiceProcess.cmdMethod['setMission_DynPoints'] = function (data, cb) {
            console.log('setMission_DynPoints', data);

            let currentPos = {
                lat: objectData.posInt.lat / 1e7, lon: objectData.posInt.lon / 1e7
            }

            let gotoList = data.gotoList ? data.gotoList : []
            let returnList = data.returnList ? data.returnList : []

            let pointArray = _.union(gotoList, [data.target], returnList, [data.landing])

            let distanceCheckResult = SystemResCheck.distanceCheck(currentPos, pointArray)

            if (distanceCheckResult && !SystemResCheck.expireDateCheck(objectData.timeUnixUsec.toISOString())) {
                setMissionDynPoints(data, cb)
            } else {
                if (cb) cb(false)
            }

        }

        NwServiceProcess.cmdMethod['setMission_InAirDynPoints'] = function (data, cb) {
            console.log('setMission_InAirDynPoints', data);

            let currentPos = {
                lat: objectData.posInt.lat / 1e7, lon: objectData.posInt.lon / 1e7
            }

            let gotoList = data.gotoList ? data.gotoList : []
            let returnList = data.returnList ? data.returnList : []

            let pointArray = _.union(gotoList, [data.target], returnList, [data.landing])

            let distanceCheckResult = SystemResCheck.distanceCheck(currentPos, pointArray)

            if (distanceCheckResult && !SystemResCheck.expireDateCheck(objectData.timeUnixUsec.toISOString())) {
                setMissionInAirDynPoints(data, cb)
            } else {
                if (cb) cb(false)
            }

        }

        function setMissionDynPoints(data, cb) {
            //get value from config
            let flyAlt = SystemConfig.get('alt_flight')
            let takeoffAlt = SystemConfig.get('alt_flight')//same as flight altitude
            let dropAlt = SystemConfig.get('alt_drop')

            let flightSpeed = SystemConfig.get('speed_ground')
            // let takeoffSpeed = SystemConfig.get('speed_takeoff')
            // let droppingSpeed = SystemConfig.get('speed_dropping')
            // let flyoutSpeed = SystemConfig.get('speed_flyout')
            // let landingSpeed = SystemConfig.get('speed_landing')

            let gotoPoints = SystemConfig.get('goto_points')
            let returnPoints = SystemConfig.get('return_points')
            let delayStartTime = SystemConfig.get('delay_start_time')

            let moveServo = SystemConfig.get('servo_max')

            let delayLanding = 1

            let missionList = []
            //home
            missionList.push({ cmd: 16, lat: data.current.lat, lon: data.current.lon, alt: 0, frame: 3 })
            //set Ground speed m/s
            missionList.push({ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 0, param2: flightSpeed } })
            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: takeoffSpeed } },//set Climb Speed for takeoff m/s

            //takeOff
            missionList.push({ cmd: 22, lat: 0, lon: 0, alt: takeoffAlt, frame: 3 })

            //wayPoint
            if (gotoPoints > 0) {
                // for (let index = 0; index < gotoPoints; index++) {
                //     // let wayPointIndex = 1 + index
                //     missionList.push({ cmd: 16, lat: data[index].lat, lon: data[index].lon, alt: flyAlt, frame: 3 })
                // }
                for (let index = 0; index < data.gotoList.length; index++) {
                    const gotoPoint = data.gotoList[index];
                    missionList.push({ cmd: 16, lat: gotoPoint.lat, lon: gotoPoint.lon, alt: flyAlt, frame: 3 })
                }
            }

            let targetPos = data.target //data[gotoPoints + 1]
            //target and wait for 1s
            missionList.push({ cmd: 16, lat: targetPos.lat, lon: targetPos.lon, alt: flyAlt, frame: 3, params: { param1: 1 } })
            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 3, param2: droppingSpeed } },//set Descent Speed for dropping  m/s
            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: flyoutSpeed } },//set Climb Speed for flyout m/s

            //move down to drop
            missionList.push({ cmd: 16, lat: targetPos.lat, lon: targetPos.lon, alt: dropAlt, frame: 3 })
            //move servo
            missionList.push({ cmd: 183, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: servoPin, param2: moveServo } })
            //move to fry
            missionList.push({ cmd: 16, lat: targetPos.lat, lon: targetPos.lon, alt: flyAlt, frame: 3 })

            //wayPoint2
            if (returnPoints > 0) {
                // for (let index = 0; index < returnPoints; index++) {
                //     let wayPointIndex = gotoPoints + 1 + index
                //     missionList.push({ cmd: 16, lat: data[wayPointIndex].lat, lon: data[wayPointIndex].lon, alt: flyAlt, frame: 3 })
                // }
                for (let index = 0; index < data.returnList.length; index++) {
                    const returnPoint = data.returnList[index];
                    missionList.push({ cmd: 16, lat: returnPoint.lat, lon: returnPoint.lon, alt: flyAlt, frame: 3 })
                }
            }

            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 3, param2: landingSpeed } },//set Descent Speed for landing  m/s

            let landingPos = data.landing//data[gotoPoints + 1 + returnPoints + 1]
            //wayPoint end and wait for delayLanding s
            missionList.push({ cmd: 16, lat: landingPos.lat, lon: landingPos.lon, alt: flyAlt, frame: 3, params: { param1: delayLanding } })
            //landing
            missionList.push({ cmd: 21, lat: landingPos.lat, lon: landingPos.lon, alt: 1, frame: 3 })

            //console.log(missionList);
            mvLink.addWaypoint(missionList, function (result) {
                if (cb) cb(result)
            })

            lastMission = data
            lastMission.type = 'target'
            lastMission.seqNumber = 8 + (data.gotoList ? data.gotoList.length : 0) + (data.returnList ? data.returnList.length : 0)
            console.log('lastMission.seqNumber', lastMission.seqNumber);
            // mvLink.getAllMission(function (wp) {
            //     cb(wp)
            // })
        }

        //no takeoff
        //no move down and up at target, it will move down and up from before and after the target
        //no landing, change to LOITER_UNLIM
        function setMissionInAirDynPoints(data, cb) {
            //get value from config
            let flyAlt = SystemConfig.get('alt_flight')
            let takeoffAlt = SystemConfig.get('alt_flight')//same as flight altitude
            let dropAlt = SystemConfig.get('alt_drop')

            let flightSpeed = SystemConfig.get('speed_ground')
            // let takeoffSpeed = SystemConfig.get('speed_takeoff')
            // let droppingSpeed = SystemConfig.get('speed_dropping')
            // let flyoutSpeed = SystemConfig.get('speed_flyout')
            // let landingSpeed = SystemConfig.get('speed_landing')

            let gotoPoints = SystemConfig.get('goto_points')
            let returnPoints = SystemConfig.get('return_points')
            let delayStartTime = SystemConfig.get('delay_start_time')

            let moveServo = SystemConfig.get('servo_max')

            let missionList = []
            //home
            missionList.push({ cmd: 16, lat: data.current.lat, lon: data.current.lon, alt: 0, frame: 3 })
            //set Ground speed m/s
            missionList.push({ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 0, param2: flightSpeed } })
            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: takeoffSpeed } },//set Climb Speed for takeoff m/s

            // //takeOff
            // missionList.push({ cmd: 22, lat: 0, lon: 0, alt: takeoffAlt, frame: 3 })

            //wayPoint
            if (gotoPoints > 0) {
                // for (let index = 0; index < gotoPoints; index++) {
                //     // let wayPointIndex = 1 + index
                //     missionList.push({ cmd: 16, lat: data[index].lat, lon: data[index].lon, alt: flyAlt, frame: 3 })
                // }
                for (let index = 0; index < data.gotoList.length; index++) {
                    const gotoPoint = data.gotoList[index];
                    missionList.push({ cmd: 16, lat: gotoPoint.lat, lon: gotoPoint.lon, alt: flyAlt, frame: 3 })
                }
            }

            let targetPos = data.target //data[gotoPoints + 1]
            //target and wait for 0s 
            // missionList.push({ cmd: 16, lat: targetPos.lat, lon: targetPos.lon, alt: flyAlt, frame: 3, params: { param1: 0 } })

            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 3, param2: droppingSpeed } },//set Descent Speed for dropping  m/s
            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: flyoutSpeed } },//set Climb Speed for flyout m/s

            //move down to drop
            missionList.push({ cmd: 16, lat: targetPos.lat, lon: targetPos.lon, alt: dropAlt, frame: 3 })
            //move servo
            missionList.push({ cmd: 183, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: servoPin, param2: moveServo } })

            //move to fry
            // missionList.push({ cmd: 16, lat: targetPos.lat, lon: targetPos.lon, alt: flyAlt, frame: 3 })

            //wayPoint2
            if (returnPoints > 0) {
                // for (let index = 0; index < returnPoints; index++) {
                //     let wayPointIndex = gotoPoints + 1 + index
                //     missionList.push({ cmd: 16, lat: data[wayPointIndex].lat, lon: data[wayPointIndex].lon, alt: flyAlt, frame: 3 })
                // }
                for (let index = 0; index < data.returnList.length; index++) {
                    const returnPoint = data.returnList[index];
                    missionList.push({ cmd: 16, lat: returnPoint.lat, lon: returnPoint.lon, alt: flyAlt, frame: 3 })
                }
            }

            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 3, param2: landingSpeed } },//set Descent Speed for landing  m/s

            let landingPos = data.landing//data[gotoPoints + 1 + returnPoints + 1]
            //wayPoint end and wait for 0s
            missionList.push({ cmd: 16, lat: landingPos.lat, lon: landingPos.lon, alt: flyAlt, frame: 3, params: { param1: 0 } })
            // //landing
            // missionList.push({ cmd: 21, lat: landingPos.lat, lon: landingPos.lon, alt: 1, frame: 3 })

            //LOITER_UNLIM
            missionList.push({ cmd: 17, lat: landingPos.lat, lon: landingPos.lon, alt: flyAlt, frame: 3, params: { param1: 0 } })

            //console.log(missionList);
            mvLink.addWaypoint(missionList, function (result) {
                if (cb) cb(result)
            })

            lastMission = data
            lastMission.type = 'target'
            lastMission.seqNumber = 8 + (data.gotoList ? data.gotoList.length : 0) + (data.returnList ? data.returnList.length : 0)
            console.log('lastMission.seqNumber', lastMission.seqNumber);
            // mvLink.getAllMission(function (wp) {
            //     cb(wp)
            // })
        }

        NwServiceProcess.cmdMethod['setMission_DynPoints_Loop'] = function (data, cb) {
            // mvLink.MissionClearAll(function () {
            // console.log('MissionClearAll');

            let currentPos = {
                lat: objectData.posInt.lat / 1e7, lon: objectData.posInt.lon / 1e7
            }

            let loopList = data.loopList ? data.loopList : []

            let pointArray = _.union(loopList, [data.landing])

            let distanceCheckResult = SystemResCheck.distanceCheck(currentPos, pointArray)

            if (distanceCheckResult) {
                setMissionDynPointsLoop(data, cb)
            } else {
                if (cb) cb(false)
            }
            // })
        }

        function setMissionDynPointsLoop(data, cb) {
            console.log('setMission', data);
            //get value from config
            let flyAlt = SystemConfig.get('alt_flight')
            let takeoffAlt = SystemConfig.get('alt_flight')//same as flight altitude
            let dropAlt = SystemConfig.get('alt_drop')

            let flightSpeed = SystemConfig.get('speed_ground')

            let loopPoints = SystemConfig.get('loop_points')

            let loopRepeat = SystemConfig.get('loop_repeat')

            let missionList = []
            //home
            missionList.push({ cmd: 16, lat: data.current.lat, lon: data.current.lon, alt: 0, frame: 3 })

            //takeOff
            missionList.push({ cmd: 22, lat: 0, lon: 0, alt: takeoffAlt, frame: 3 })

            //set Ground speed m/s
            missionList.push({ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 0, param2: flightSpeed } })
            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: takeoffSpeed } },//set Climb Speed for takeoff m/s


            //wayPoint
            if (loopPoints > 0) {
                // for (let index = 0; index < gotoPoints; index++) {
                //     // let wayPointIndex = 1 + index
                //     missionList.push({ cmd: 16, lat: data[index].lat, lon: data[index].lon, alt: flyAlt, frame: 3 })
                // }
                for (let index = 0; index < data.loopList.length; index++) {
                    const point = data.loopList[index];
                    missionList.push({ cmd: 16, lat: point.lat, lon: point.lon, alt: flyAlt, frame: 3 })
                }
            }

            //infinite loop to seq 3
            missionList.push({ cmd: 177, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 3, param2: -1 } })

            let landingPos = data.landing//data[gotoPoints + 1 + returnPoints + 1]
            // //wayPoint end and wait for 1s
            missionList.push({ cmd: 16, lat: landingPos.lat, lon: landingPos.lon, alt: flyAlt, frame: 3, params: { param1: 1 } })
            //landing
            missionList.push({ cmd: 21, lat: landingPos.lat, lon: landingPos.lon, alt: 1, frame: 3 })

            //console.log(missionList);
            mvLink.addWaypoint(missionList, function (result) {
                if (cb) cb(result)
            })

            lastMission = data
            lastMission.type = 'loop'
        }

        function setGoHomeMission(data, cb) {
            console.log('setMission', data);

            let landingPos = data.landing

            //get value from config
            let flyAlt = SystemConfig.get('alt_flight')
            let takeoffAlt = SystemConfig.get('alt_flight')//same as flight altitude
            let dropAlt = SystemConfig.get('alt_drop')

            let flightSpeed = SystemConfig.get('speed_ground')

            //let loopPoints = SystemConfig.get('loop_points')

            let missionList = []
            //home
            missionList.push({ cmd: 16, lat: landingPos.lat, lon: landingPos.lon, alt: takeoffAlt, frame: 3 })
            //takeOff
            missionList.push({ cmd: 22, lat: landingPos.lat, lon: landingPos.lon, alt: takeoffAlt, frame: 3 })

            //set Ground speed m/s
            missionList.push({ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 0, param2: flightSpeed } })
            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: takeoffSpeed } },//set Climb Speed for takeoff m/s

            // //wayPoint end and wait for 1s
            missionList.push({ cmd: 16, lat: landingPos.lat, lon: landingPos.lon, alt: flyAlt, frame: 3, params: { param1: 1 } })
            //landing
            missionList.push({ cmd: 21, lat: landingPos.lat, lon: landingPos.lon, alt: 1, frame: 3 })

            //console.log(missionList);
            mvLink.addWaypoint(missionList, function (result) {
                if (cb) cb(result)
            })

        }

        function setEmergencyGoHomeMission(data, cb) {
            console.log('setEmergencyGoHomeMission', data);

            let landingPos = data.landing

            let flyAlt = SystemConfig.get('alt_flight')
            let flightSpeed = SystemConfig.get('speed_ground')
            let missionList = []

            //home
            missionList.push({ cmd: 16, lat: landingPos.lat, lon: landingPos.lon, alt: flyAlt, frame: 3 })

            //set Ground speed m/s
            missionList.push({ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 0, param2: flightSpeed } })
            // //wayPoint end and wait for 1s
            missionList.push({ cmd: 16, lat: landingPos.lat, lon: landingPos.lon, alt: flyAlt, frame: 3, params: { param1: 1 } })
            //landing
            missionList.push({ cmd: 21, lat: landingPos.lat, lon: landingPos.lon, alt: 1, frame: 3 })

            //console.log(missionList);
            mvLink.addWaypoint(missionList, function (result) {
                if (cb) cb(result)
            })

        }

        //assume the drone currently on the air
        //so just need to setEmergencyGoHomeMission and start auto mode 
        function doEmergencyGoHome(data, cb, endMissionCallback) {
            clearLoopAutoEndingHandle() // just in case this method call manually

            // if (lastMission) {

            // } else {

            // }

            //check if currently is in auto(3) mode or not
            //if it is then switch to posHold first 
            //and new mission then can be set
            let currentMode = mvLink.get('customMode')
            if (currentMode == 3) {
                doPosHold(null, function () {
                    setTimeout(() => {
                        doEmergencyGoHome(data, cb)
                    }, 500);
                })
                return
            }

            setEmergencyGoHomeMission(data, function (result) {
                mvLink.SetMode(3, function () {
                    mode_state = 'auto'
                    console.log('start EmergencyGoHome');


                    let successTakeoff = false
                    let seqChangeHandle = function (event, seq) {
                        console.log('seq', seq);
                        if (seq == 1) {
                            //console.log('seq > takeOffSeq', seq);
                            successTakeoff = true
                        }
                        if (successTakeoff && seq == 0) {
                            console.log('end EmergencyGoHome mission');
                            //change to landing
                            mvLink.SetMode(9, function () {
                                /// mvLink.MissionStart()
                                //mvLink.doSetServo(throttleGeneratePin, 900)
                                RcChannelsOverride(throttleCh, 900)
                                //mode_state = data
                                if (endMissionCallback) endMissionCallback()
                            })
                            mvLink.off('change:seq', seqChangeHandle)
                        }
                    }

                    mvLink.on('change:seq', seqChangeHandle)

                    if (cb) cb()
                })
            })

        }

        function returnToRemoteControl() {
            RcChannelsOverrideObj['chan' + forwardCh + 'Raw'] = 0
            RcChannelsOverrideObj['chan' + throttleCh + 'Raw'] = 0
            mvLink.RcChannelsOverrideZero()
        }

        function stopMove(cb, isNotReturnToRemote) {
            // mvLink.guidedVelocity(0, 0, 0, function (result) {
            //     //mvLink.guidedChangeAlt(alt, function (result) {
            //     console.log('moveVelocity', 0, 0, 0, result);
            //     if (cb) cb(result)
            // })
            console.log('stopVelocity');
            if (withoutRemote) {
                RcChannelsOverrideObj['chan' + forwardCh + 'Raw'] = 1500
                RcChannelsOverrideObj['chan' + throttleCh + 'Raw'] = 1500
                mvLink.RcChannelsOverride(RcChannelsOverrideObj)
            } else {
                if (isNotReturnToRemote) {
                    RcChannelsOverrideObj['chan' + forwardCh + 'Raw'] = 1500
                    RcChannelsOverrideObj['chan' + throttleCh + 'Raw'] = 1500

                    mvLink.RcChannelsOverrideZero(RcChannelsOverrideObj)
                } else {
                    returnToRemoteControl()
                }
            }

            if (cb) cb()
        }

        //time in second
        //if has gps mode maybe 5: "Loiter", or  16: "PosHold",
        //if no gps mode maybe 2: "AltHold",
        function moveForward(value, time, cb, mode) {

            //let heading = objectData.heading
            // moveVelocity(heading, value, cb)
            console.log('forward', value, time);

            RcChannelsOverrideObj['chan' + forwardCh + 'Raw'] = 1500 - value
            RcChannelsOverrideObj['chan' + throttleCh + 'Raw'] = 1500

            async.series([function (callback) {
                if (withoutRemote) {
                    mvLink.RcChannelsOverride(RcChannelsOverrideObj)
                } else {
                    withRemoteAndAutoControl = true // for start heartbeat
                    mvLink.RcChannelsOverrideZero(RcChannelsOverrideObj)
                }
                callback(null);

            }, function (callback) {
                if (mode) {
                    setTimeout(() => {
                        mvLink.SetMode(mode, function () {
                            callback(null);
                        })
                    }, 100);

                } else {
                    callback(null)
                }
            }], function () {

                if (time) {
                    time = time * 1000
                    setTimeout(() => {
                        stopMove(cb)
                    }, time);
                } else {
                    if (cb) cb()
                }
            })
        }

        function moveBackward(cb, mode) {
            let moveSpeed = SystemConfig.get('move_speed')
            let moveTime = SystemConfig.get('move_time')

            moveForward(-moveSpeed, moveTime, cb, mode)
        }

        function jammingManuever(data, cb) {
            let currentMode = mvLink.get('customMode')

            async.series([function (callback) {
                if (currentMode != 2) {
                    //change mode to AltHold
                    mvLink.SetMode(2, function () {
                        callback(null);
                    })
                } else {
                    callback(null);
                }

            }, function (callback) {

                let moveSpeed = SystemConfig.get('move_speed')
                //let moveTime = SystemConfig.get('move_time')

                moveForward(-moveSpeed, null, function () {

                    let change_customModeEvent = null
                    let cancelCallback = gpsWorkingCallback(function () {
                        console.log('gpsWorkingCallback');
                        if (change_customModeEvent) {
                            mvLink.off('change:customMode', change_customModeEvent)
                            change_customModeEvent = null
                        }
                        stopMove(function () {
                            callback(null);
                        }, true)
                    })

                    change_customModeEvent = function (obj, modeId) {
                        if (modeId == 16) { //PosHold
                            console.log('change customMode to PosHold');
                            stopMove(function () {
                                returnToRemoteControl()
                            }, true)

                            if (cancelCallback) {
                                cancelCallback()
                            }

                            if (change_customModeEvent) {
                                mvLink.off('change:customMode', change_customModeEvent)
                                change_customModeEvent = null
                            }

                        }
                    }

                    mvLink.on('change:customMode', change_customModeEvent)
                    // moveTime = moveTime * 1000
                    // setTimeout(() => {
                    //     //stop move without return to remote (if it have)
                    //     stopMove(function () {
                    //         callback(null);
                    //     }, true)
                    // }, moveTime);
                })

                //moveBackward(callback)//mode is null
                // todo
                //recheck working or not every move backward call
                //or moving until working state event callback then call stopMove

            }, function (callback) {
                doPosHold(null, function () {
                    callback()
                })

            }], function () {
                doEmergencyGoHome(lastMission, function () {
                    if (!withoutRemote) {
                        returnToRemoteControl()
                    }

                }, cb)
            })
        }

        function setMissionTakeoff() {
            console.log('setMission', data);
            //get value from config
            let takeoffAlt = SystemConfig.get('alt_flight')//same as flight altitude

            let flightSpeed = SystemConfig.get('speed_ground')
            // let takeoffSpeed = SystemConfig.get('speed_takeoff')

            let missionList = []
            //home
            missionList.push({ cmd: 16, lat: data.current.lat, lon: data.current.lon, alt: 0, frame: 3 })

            //takeOff
            missionList.push({ cmd: 22, lat: 0, lon: 0, alt: takeoffAlt, frame: 3 })

            //set Ground speed m/s
            missionList.push({ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 0, param2: flightSpeed } })
            //{ cmd: 178, lat: 0, lon: 0, alt: 0, frame: 3, params: { param1: 2, param2: takeoffSpeed } },//set Climb Speed for takeoff m/s


            //console.log(missionList);
            mvLink.addWaypoint(missionList, function (result) {
                if (cb) cb(result)
            })

            lastMission = data
            lastMission.type = 'takeoff'
        }

        //set servo to default
        let servoPin = 10
        let throttleGeneratePin = 11
        let throttleCh = 3
        let forwardCh = 2
        let servoControlCh = 6

        RcChannelsOverrideObj = {}

        let withoutRemote = false
        let withRemoteAndAutoControl = false

        let chan2RawFirstTime = true
        chan2Raw(mvLink.get('chan2Raw'))

        function chan2Raw(ch2) {
            //console.log('chan 2 raw', ch2);
            if (chan2RawFirstTime) {

                let ch8 = mvLink.get('chan8Raw')
                if (ch2 != undefined || ch8 != undefined) {
                    chan2RawFirstTime = false
                    console.log('chan2RawFirstTime', ch2, ch8);
                    if (ch2 == 900 || ch8 == 1234) {

                        RcChannelsOverrideObj['chan3Raw'] = 900
                        RcChannelsOverrideObj['chan8Raw'] = 1234

                        withoutRemote = true

                        console.log('No remote System.');
                    }
                    else {
                        console.log('System being with remote.');
                    }
                }
            }
        }
        function RcChannelsOverride(ch, pwm) {

            if (withoutRemote) {
                RcChannelsOverrideObj['chan' + ch + 'Raw'] = pwm
                mvLink.RcChannelsOverride(RcChannelsOverrideObj)
            }
        }

        //interval for HEARTBEAT to flight controller
        setInterval(() => {
            //check if it has remote or not
            if (withoutRemote) {
                //for deceive flight controller
                mvLink.RcChannelsOverride(RcChannelsOverrideObj)
            } else if (withRemoteAndAutoControl) {
                mvLink.RcChannelsOverrideZero(RcChannelsOverrideObj)
            }
        }, 1000);

        setTimeout(() => {
            //set default pws
            //mvLink.doSetServo(throttleGeneratePin, 900, function () {
            // mvLink.doSetServo(servoPin, SystemConfig.get('servo_min'), function () {
            //     //mvLink.doSetServo(8, SystemConfig.get('servo_min'))
            //     //mvLink.RcChannelsOverride(RcChannelsOverrideObj)
            //     RcChannelsOverride(throttleCh, 900)
            // })
            //})

            if (withoutRemote) {
                RcChannelsOverride(throttleCh, 900)
            } else {
                mvLink.on('change:chServoCon', function (self, val) {
                    console.log('change:chServoCon', val);
                    if (val) {
                        mvLink.doSetServo(servoPin, SystemConfig.get('servo_max'))
                    }
                    else {
                        mvLink.doSetServo(servoPin, SystemConfig.get('servo_min'))
                    }

                })

            }
        }, 1000);

        //     mvLink.doSetServo(11, 1500)
        // }, 100);

        NwServiceProcess.cmdMethod['doSetServo'] = function (data, cb) {
            console.log('doSetServo service');
            mvLink.doSetServo(data.pid, data.pwm, cb)
        }

        function resetSeq(cb) {
            mvLink.MissionSetCurrent(0, cb)
        }

        let loopTimeoutHandle = null
        let voltageBatteryChangeHandle = null

        function clearLoopAutoEndingHandle() {
            if (loopTimeoutHandle) {
                clearTimeout(loopTimeoutHandle)
                loopTimeoutHandle = null
            }
            if (voltageBatteryChangeHandle) {
                mvLink.off('change:voltageBattery', voltageBatteryChangeHandle)
                voltageBatteryChangeHandle = null
            }
        }

        let targetAlt = null
        function goUpDown(altChange, cb) {
            //objectData.alt
            targetAlt = targetAlt ? targetAlt : (objectData.relativeAlt / 1000)

            targetAlt = targetAlt + altChange
            //alt = alt * 100

            console.log('goUpDown', altChange, targetAlt);

            let lat = objectData.posInt.lat / 1e7
            let lon = objectData.posInt.lon / 1e7

            mvLink.guidedWP(targetAlt, lat, lon, function (result) {
                //mvLink.guidedChangeAlt(alt, function (result) {
                console.log('guidedWP', result);
                cb(result)
            })
        }

        function gotoPosition(lat, lon, alt) {
            if (!alt) {
                if (targetAlt) {
                    alt = targetAlt
                } else {
                    alt = objectData.relativeAlt / 1000
                }
            }
            targetAlt = alt

            mvLink.guidedWP(alt, lat, lon, function (result) {
                //mvLink.guidedChangeAlt(alt, function (result) {
                console.log('gotoPosition', alt, lat, lon, result);
                cb(result)
            })
        }

        // function moveVelocity(degree, value, cb, alt) {

        //     alt = alt ? alt : 0

        //     var angle = degree * Math.PI / 180; //degress converted to radians
        //     let lat = Math.cos(angle);
        //     let lon = Math.sin(angle);

        //     lat = lat * value
        //     lon = lon * value

        //     console.log('moveVelocity', degree, lat, lon, alt);
        //     mvLink.guidedVelocity(alt, lat, lon, function (result) {
        //         //mvLink.guidedChangeAlt(alt, function (result) {
        //         console.log('moveVelocity', alt, lat, lon, result);
        //         if (cb) cb(result)

        //         setTimeout(() => {
        //             stopMove()
        //         }, 10000);
        //     })
        // }

        function doStartTakeoff(data, cb, endMissionCallback) {
            //console.log('takeoff', data)

            if (!SystemResCheck.expireDateCheck(objectData.timeUnixUsec.toISOString())) {
                // setMissionDynPoints(data, cb)
                let takeoffAlt = SystemConfig.get('alt_flight')//same as flight altitude
                console.log('takeoffAlt', takeoffAlt)

                //change to Guided mode
                mvLink.SetMode(4, function () {

                    RcChannelsOverride(throttleCh, 900)
                    mode_state = "guided"

                    mvLink.Arming(true, function () {
                        setTimeout(() => {
                            mvLink.navTakeoff(takeoffAlt, function (result) {
                                console.log('navTakeoff', result);
                                if (cb) cb()
                            })
                        }, 1000);
                    })
                })

            } else {
                if (cb) cb(false)
            }
        }

        function yawToTargetCallback(target, speed, cb) {

            const exceptDegVal = 1
            let estimateTimeoutHandle = null

            //just regis heading changed event and compare result
            let headingChangeHandle = function (obj, value) {
                //console.log('headingChangeHandle', value);
                let diff = target - value

                //do not care which side of circle
                let absDiff = Math.abs(diff)

                if (absDiff > 180) {
                    absDiff = 360 - absDiff
                }

                if (absDiff <= exceptDegVal) {
                    mvLink.off('change:heading', headingChangeHandle)
                    headingChangeHandle = null
                    if (estimateTimeoutHandle) {
                        clearTimeout(estimateTimeoutHandle)
                    }

                    cb(absDiff)
                }
            }
            mvLink.on('change:heading', headingChangeHandle)

            if (speed) {
                let currentHeading = mvLink.get('heading')
                let diff = target - currentHeading

                //do not care which side of circle
                let absDiff = Math.abs(diff)

                if (absDiff > 180) {
                    absDiff = 360 - absDiff
                }

                let timeOutEstimate = absDiff / speed //in second
                timeOutEstimate = timeOutEstimate * 1.5
                console.log('timeOutEstimate', timeOutEstimate);
                estimateTimeoutHandle = setTimeout(() => {
                    console.log('call Time out');
                    estimateTimeoutHandle = null
                    if (headingChangeHandle != null) {
                        mvLink.off('change:heading', headingChangeHandle)
                        cb(-1)
                    }

                }, timeOutEstimate * 1000);

            }
        }

        function setConditionYaw(target, speed, cb) {

            let currentModeId = mvLink.get('customMode')
            console.log('currentModeId', currentModeId);

            async.series([
                function (callback) {
                    if (currentModeId != 4) {
                        //change to Guided mode
                        mvLink.SetMode(4, function () {
                            mode_state = "guided"
                            callback(null);
                        })
                    } else {
                        callback(null);
                    }

                }
            ], function () {
                console.log('start yawToTargetCallback', target, speed);
                mvLink.setConditionYaw(target, speed, function (result) {
                    yawToTargetCallback(target, speed, function () {
                        console.log('fin yawToTargetCallback', result);
                        if (currentModeId != 4 && currentModeId != 3) {// 3 is auto mode
                            mvLink.SetMode(currentModeId, function () {
                                cb(result)
                            })
                        } else {
                            cb(result)
                        }
                    })
                    //console.log('fin setConditionYaw', result);
                })
            })
        }

        function doStart(data, cb, endMissionCallback) {

            let currentPos = {
                lat: objectData.posInt.lat / 1e7, lon: objectData.posInt.lon / 1e7
            }

            let pointArray = null

            //check for distance from current position
            if (lastMission.type == 'target') {
                let gotoList = lastMission.gotoList ? lastMission.gotoList : []
                let returnList = lastMission.returnList ? lastMission.returnList : []

                pointArray = _.union(gotoList, [lastMission.target], returnList, [lastMission.landing])

                let distanceCheckResult = SystemResCheck.distanceCheck(currentPos, pointArray)

                if (!distanceCheckResult || SystemResCheck.expireDateCheck(objectData.timeUnixUsec.toISOString())) {
                    //something wrong
                    return
                }

            } else if (lastMission.type == 'loop') {
                //do this for loop also
                let loopList = lastMission.loopList ? lastMission.loopList : []

                let pointArray = _.union(loopList, [lastMission.landing])

                let distanceCheckResult = SystemResCheck.distanceCheck(currentPos, pointArray)
                if (!distanceCheckResult || SystemResCheck.expireDateCheck(objectData.timeUnixUsec.toISOString())) {
                    //something wrong
                    return
                }

            } else if (lastMission.type == 'takeoff') {
                //do this for loop also
            } else if (lastMission.type == 'loop') {
                //do this for loop also
            }

            if (mode_state == 'PosHold') {
                doStartOnFly(data, cb, endMissionCallback)

            } else {
                doStartFromGround(data, cb, endMissionCallback)
            }

            clearLoopAutoEndingHandle()//just in case

            if (lastMission.type == 'loop') {
                //do go home condition
                //let loopRepeat = SystemConfig.get('loop_repeat')

                let loopTimeout = SystemConfig.get('loop_timeout')
                let homeVoltage = SystemConfig.get('home_voltage')

                if (loopTimeout > 0) {
                    // do time out condition
                    loopTimeoutHandle = setTimeout(() => {
                        console.log('loopTimeout');
                        clearLoopAutoEndingHandle()
                        if (objectData.customMode == 'Auto') {
                            doPosHold(data, function () {
                                doGoHome(data)
                            })
                        }
                    }, loopTimeout * 1000);
                }

                if (homeVoltage > 0) {
                    // go home when voltage lesser then condition
                    voltageBatteryChangeHandle = function (value) {
                        let voltage = mvLink.get('voltageBattery') / 1000

                        //console.log(homeVoltage, voltage);
                        if (homeVoltage > voltage) {
                            console.log('homeVoltage');
                            clearLoopAutoEndingHandle()
                            if (objectData.customMode == 'Auto') {
                                doPosHold(data, function () {
                                    doGoHome(data)
                                })
                            }
                        }

                    }
                    mvLink.on('change:voltageBattery', voltageBatteryChangeHandle)
                }
            }
        }

        function doStartOnFly(data, cb, endMissionCallback) {
            //change mode to auto
            mvLink.SetMode(3, function (result) {
                //console.log('SetMode(3', result);
                if (result == 0) {
                    mode_state = 'auto'
                    //console.log('MissionStart');
                    // setTimeout(() => {

                    // }, 1000);

                    if (cb) cb(data)
                    setTimeout(() => {
                        //mvLink.MissionStart(0, 0)
                        //mvLink.doSetServo(throttleGeneratePin, 1200)//start hare
                        RcChannelsOverride(throttleCh, 1500)
                        //mvLink.RcChannelsOverride(1200)
                        //mvLink.ManualControl(500)

                        // setTimeout(() => {
                        //     //mvLink.doSetServo(throttleGeneratePin, 900)
                        //     RcChannelsOverride(throttleCh, 900)
                        // }, 2000);

                        let takeOffSeq = 2
                        //let takeoffTimeOutHandle = null
                        let successTakeoff = false
                        let seqChangeHandle = function (event, seq) {
                            console.log(successTakeoff, seq);
                            if (seq > takeOffSeq) {
                                //console.log('seq > takeOffSeq', seq);
                                // if (takeoffTimeOutHandle) {
                                //     clearTimeout(takeoffTimeOutHandle)
                                // }
                                successTakeoff = true
                            }
                            if (seq == lastMission.seqNumber) {
                                RcChannelsOverride(throttleCh, 900)
                                console.log("last mission");
                            }
                            if (successTakeoff && seq == 0) {
                                //console.log('end mission');
                                //change to landing
                                mvLink.SetMode(9, function () {
                                    /// mvLink.MissionStart()
                                    //mvLink.doSetServo(throttleGeneratePin, 900)
                                    RcChannelsOverride(throttleCh, 900)
                                    //mode_state = data
                                    if (endMissionCallback) endMissionCallback()
                                })
                                mvLink.off('change:seq', seqChangeHandle)
                            }
                        }

                        mvLink.on('change:seq', seqChangeHandle)

                        // if (SystemConfig.get('timeout_takeoff') > 0) {

                        //     //console.log('start takeoffTimeOutHandle', SystemConfig.get('timeout_takeoff') * 1000);
                        //     takeoffTimeOutHandle = setTimeout(() => {
                        //         //console.log('end takeoffTimeOutHandle');
                        //         //mvLink.off('change:seq', seqChangeHandle)

                        //         //console.log('start takeoffTime Return to home landing');
                        //         //landing
                        //         mvLink.SetMode(9, function () {
                        //             /// mvLink.MissionStart()
                        //             //mvLink.doSetServo(throttleGeneratePin, 900)
                        //             RcChannelsOverride(throttleCh, 900)
                        //             //mode_state = data
                        //         })

                        //     }, SystemConfig.get('timeout_takeoff') * 1000);

                        // }

                    }, 1000);
                } else {
                    console.log('Can not switch to auto mode.');
                    mvLink.Arming(false)
                    mode_state = 'disarming'
                    if (cb) cb(mode_state)
                }

            })
        }
        //use this for ground start 
        function doStartFromGround(data, cb, endMissionCallback) {

            async.series([
                (callback) => {

                    if (objectData.customMode != 'Auto') {
                        //change mode to Stabilize
                        mvLink.SetMode(0, function () {
                            callback(null);
                        })
                    } else {
                        callback(null);
                    }

                },
                (callback) => {
                    mvLink.Arming(true, function () {
                        //change mode to auto
                        mvLink.SetMode(3, function (result) {
                            //console.log('SetMode(3', result);
                            if (result == 0) {
                                mode_state = 'auto'
                                //console.log('MissionStart');
                                // setTimeout(() => {

                                // }, 1000);

                                if (cb) cb(data)
                                setTimeout(() => {
                                    //mvLink.MissionStart(0, 0)
                                    //mvLink.doSetServo(throttleGeneratePin, 1200)//start hare
                                    RcChannelsOverride(throttleCh, 1500)
                                    //mvLink.RcChannelsOverride(1200)
                                    //mvLink.ManualControl(500)

                                    // setTimeout(() => {
                                    //     //mvLink.doSetServo(throttleGeneratePin, 900)
                                    //     RcChannelsOverride(throttleCh, 900)
                                    // }, 2000);

                                    let takeOffSeq = 2
                                    let takeoffTimeOutHandle = null
                                    let successTakeoff = false

                                    //check for GPS jamming
                                    let gpsConnectionChangeEvent = jammingCallback(function () {
                                        console.log('jammingCallback');

                                        //cancel mission
                                        if (takeoffTimeOutHandle) {
                                            clearTimeout(takeoffTimeOutHandle)
                                        }
                                        mvLink.off('change:seq', seqChangeHandle)

                                        //start jamming manuever
                                        jammingManuever(data, endMissionCallback)
                                    })

                                    let seqChangeHandle = function (event, seq) {
                                        console.log(successTakeoff, seq);
                                        if (seq > takeOffSeq) {
                                            //console.log('seq > takeOffSeq', seq);
                                            if (takeoffTimeOutHandle) {
                                                clearTimeout(takeoffTimeOutHandle)
                                            }
                                            successTakeoff = true
                                        }
                                        if (seq == lastMission.seqNumber) {
                                            RcChannelsOverride(throttleCh, 900)
                                            console.log("last mission");
                                        }
                                        if (successTakeoff && seq == 0) {
                                            //console.log('end mission');
                                            //change to landing
                                            mvLink.SetMode(9, function () {
                                                /// mvLink.MissionStart()
                                                //mvLink.doSetServo(throttleGeneratePin, 900)
                                                RcChannelsOverride(throttleCh, 900)
                                                //mode_state = data

                                                console.log("end mission");
                                                if (endMissionCallback) endMissionCallback()
                                            })
                                            mvLink.off('change:seq', seqChangeHandle)

                                            if (gpsConnectionChangeEvent) {
                                                droneState.off('change:gpsConnection', gpsConnectionChangeEvent)
                                            }
                                        }
                                    }

                                    mvLink.on('change:seq', seqChangeHandle)

                                    if (SystemConfig.get('timeout_takeoff') > 0) {

                                        //console.log('start takeoffTimeOutHandle', SystemConfig.get('timeout_takeoff') * 1000);
                                        takeoffTimeOutHandle = setTimeout(() => {
                                            //console.log('end takeoffTimeOutHandle');
                                            mvLink.off('change:seq', seqChangeHandle)

                                            //console.log('start takeoffTime Return to home landing');
                                            //landing
                                            mvLink.SetMode(9, function () {
                                                /// mvLink.MissionStart()
                                                //mvLink.doSetServo(throttleGeneratePin, 900)
                                                RcChannelsOverride(throttleCh, 900)
                                                //mode_state = data
                                            })

                                        }, SystemConfig.get('timeout_takeoff') * 1000);

                                    }

                                }, 1000);
                            } else {
                                console.log('Can not switch to auto mode.');
                                mvLink.Arming(false)
                                mode_state = 'disarming'
                                if (cb) cb(mode_state)
                            }
                        })
                    })

                    // setTimeout(() => {
                    //     mvLink.doSetServo(4, 1200)
                    //     if (cb) cb(data)
                    // }, 3000);
                }])
        }

        function doGuided(data, cb) {
            clearLoopAutoEndingHandle() // just in case this method call manually

            if (delayStartTimeOutHandle) {
                clearTimeout(delayStartTimeOutHandle)
                delete objectData.startTime
            }

            mvLink.SetMode(4, function () {
                //RcChannelsOverride(throttleCh, 900)
                mode_state = data
                if (cb) cb(data)
            })
        }

        function doLand(data, cb) {
            clearLoopAutoEndingHandle() // just in case this method call manually

            if (delayStartTimeOutHandle) {
                clearTimeout(delayStartTimeOutHandle)
                delete objectData.startTime
            }

            mvLink.SetMode(9, function () {
                //mvLink.doSetServo(throttleGeneratePin, 900)
                RcChannelsOverride(throttleCh, 900)
                mode_state = data
                if (cb) cb(data)
            })

        }

        function doPosHold(data, cb) {
            clearLoopAutoEndingHandle() // just in case this method call manually

            RcChannelsOverride(throttleCh, 1500)
            mvLink.SetMode(16, function () {

                mode_state = 'PosHold'
                resetSeq()

                if (cb) cb('PosHold')
            })

        }

        function doGoHome(data, cb) {
            clearLoopAutoEndingHandle() // just in case this method call manually

            if (lastMission) {

                if (mode_state != 'PosHold') {
                    doPosHold(data, function () {
                        setTimeout(() => {
                            doGoHome(data, cb)
                        }, 500);
                    })
                    return
                }

                setGoHomeMission(lastMission, function (result) {

                    doStartOnFly(data, cb, function () {
                        console.log('finish mission');

                        //lastMission
                        let setMissionMehtod = null
                        if (lastMission.type == 'target') {
                            setMissionMehtod = NwServiceProcess.cmdMethod['setMission_DynPoints']
                        } else if (lastMission.type == 'loop') {
                            setMissionMehtod = NwServiceProcess.cmdMethod['setMission_DynPoints_Loop']
                        }
                        if (setMissionMehtod) {
                            setMissionMehtod(lastMission)
                        } else {
                            //something wrong ?? !!!
                        }
                    })
                })
            } else {
                //something wrong??!!!
            }
        }

        let delayStartTimeOutHandle = null
        //for check and manage delay start
        function tryStart(data, cb) {
            let delayStartTime = SystemConfig.get('delay_start_time')

            if (delayStartTime > 0) {
                console.log('delayStartTime', delayStartTime);

                if (delayStartTimeOutHandle) {
                    clearTimeout(delayStartTimeOutHandle)
                }

                let currentTime = objectData.timeUnixUsec

                if (currentTime) {

                    objectData.startTime = new Date(currentTime.getTime() + (delayStartTime * 1000))
                    //objectData.startTime.setSeconds(objectData.startTime.getSeconds() + delayStartTime)
                    //console.log(delayStartTime, objectData.startTime, objectData.timeUnixUsec);
                    delayStartTimeOutHandle = setTimeout(() => {
                        console.log('delayStartTimeOut');
                        delete objectData.startTime

                        doStart(data, cb)
                        //mode_state = 'disarming' //for now

                    }, delayStartTime * 1000);

                    mode_state = 'delayStart'
                    if (cb) cb(mode_state)
                } else {
                    //system not ready yet
                }
            }
            else {
                doStart(data, cb)
            }
        }

        NwServiceProcess.cmdMethod['action'] = function (data, cb) {
            // if (data == 'start') {
            //     state = data
            // }
            console.log(data)

            if (data == 'start') {
                tryStart(data, cb)
            }
            else if (data == 'land') {
                //change mode to Land
                doLand(data, cb)
            }
            else if (data == 'stop') {
                //change mode to Loiter
                // mvLink.SetMode(5, function () {
                //     mode_state = data
                //     if (cb) cb(data)
                // })
                doPosHold(data, cb)
            }
            else if (data == 'home') {
                //change mode to RTL
                // mvLink.SetMode(6, function () {
                //     mode_state = data
                //     if (cb) cb(data)
                // })
                doGoHome(data, cb)
            }
            else if (data == 'takeoff') {
                doStartTakeoff(data, cb)
            }
            else if (data == 'guided') {
                //change mode to guided
                // mvLink.SetMode(6, function () {
                //     mode_state = data
                //     if (cb) cb(data)
                // })
                doGuided(data, cb)
            }

            else if (data == 'up') {
                //change mode to guided
                // mvLink.SetMode(6, function () {
                //     mode_state = data
                //     if (cb) cb(data)
                // })
                goUpDown(0.1, cb)
            }
            else if (data == 'down') {
                //change mode to guided
                // mvLink.SetMode(6, function () {
                //     mode_state = data
                //     if (cb) cb(data)
                // })
                goUpDown(-0.1, cb)
            }
            else if (data == 'fw') {
                //change mode to guided
                // mvLink.SetMode(6, function () {
                //     mode_state = data
                //     if (cb) cb(data)
                // })

                let moveSpeed = SystemConfig.get('move_speed')
                let moveTime = SystemConfig.get('move_time')

                moveForward(moveSpeed, moveTime, cb, 16)
            }
            else if (data == 'bw') {
                //change mode to guided
                // mvLink.SetMode(6, function () {
                //     mode_state = data
                //     if (cb) cb(data)
                // })

                let moveSpeed = SystemConfig.get('move_speed')
                let moveTime = SystemConfig.get('move_time')

                moveForward(-moveSpeed, moveTime, cb)
            }
            else if (data == 'stopv') {
                //change mode to guided
                // mvLink.SetMode(6, function () {
                //     mode_state = data
                //     if (cb) cb(data)
                // })
                stopMove()
            }
        }

        NwServiceProcess.cmdMethod['testCmd'] = function (data, cb) {
            console.log('testCmd');
            mvLink.SetMode(4, function () {
                mode_state = 'Guided'
                mvLink.Arming(true, function () {
                    mvLink.navTakeoff(5)
                })

            })
        }

        NwServiceProcess.cmdMethod['getMapPositionData'] = function (data, cb) {
            // console.log('getInfo');
            cb({
                gps: SensorSystem.gps,
                status: {
                    signal: gsmSignal,
                    logData: logData
                },

            })
        }

        NwServiceProcess.cmdMethod['getWpData'] = function (data, cb) {
            // console.log('getInfo');
            const Waypoints = require('../../modules/Waypoints.js');
            Waypoints.init(function () {
                self.set('currentTarget', Waypoints.nextWp(true))  // { lat: 7.88477600, lon: 98.38915320 };
                self.set('wpData', Waypoints.wpData)

                self.updateTarget() // use home (id 0) as starting point and set target to id 1 
            })
            cb(ActionControl.PositionControl.get('wpData'))
        }

        //let dbConn = require("./driver/sqliteConn.js");
        //const PositionControl = require("./control/ActionControl/PositionControl.js");
        //dbConn.dbPath = "./data/infodata.db"

        let logData = false;
        let logDate = null
        NwServiceProcess.cmdMethod['logDataState'] = function (data, cb) {
            //console.log('logDataState', data);
            if (data != null) {
                logData = data;
                if (logData) {
                    logDate = new Date()
                }
            }
            cb(logData)
        }

        NwServiceProcess.cmdMethod['getRateValues'] = function (data, cb) {
            //console.log('getRateValues', data);
            mvLink.getRateValues(function (result) {
                //console.log(result);
                cb(result)
            })
        }

        NwServiceProcess.cmdMethod['setRateValues'] = function (changeData, cb) {
            console.log('setRateValues', changeData);
            mvLink.setRateValues(changeData, function (result) {
                cb(result)
            })
        }

        NwServiceProcess.cmdMethod['loadRateValuesList'] = function (data, cb) {
            cb(RateList)
        }

        NwServiceProcess.cmdMethod['addRateValuesList'] = function (addValuesList, cb) {
            console.log('addValuesList', addValuesList);
            let addObj = {}
            addObj[addValuesList.key] = addValuesList.value
            RateList.set(addObj)
            cb(true)
        }
        NwServiceProcess.cmdMethod['deleteRateValuesList'] = function (key, cb) {
            RateList.unset(key)
            cb(true)
        }

        NwServiceProcess.cmdMethod['setConditionYaw'] = function (data, cb) {
            setConditionYaw(data.target, data.speed, cb)
        }

        NwServiceProcess.cmdMethod['doEmergencyGoHome'] = function (data, cb) {
            //doEmergencyGoHome(data, cb)
            jammingManuever(data, cb)
        }
        NwServiceProcess.cmdMethod['reverseConditionYaw'] = function (data, cb) {
            let currentHeading = mvLink.get('heading')
            const diff = 180
            let target = currentHeading - diff

            if (target < 0) {
                target = 360 + target
            }
            console.log('reverseConditionYaw', currentHeading, target);
            setConditionYaw(target, data.speed, cb)
        }

        NwServiceProcess.cmdMethod['reverseConditionYawAndMove'] = function (data, cb) {
            let currentHeading = mvLink.get('heading')
            const diff = 180
            let target = currentHeading - diff

            if (target < 0) {
                target = 360 + target
            }
            console.log('reverseConditionYaw', currentHeading, target);
            setConditionYaw(target, data.speed, function () {
                let moveSpeed = SystemConfig.get('move_speed')
                let moveTime = SystemConfig.get('move_time')

                moveForward(moveSpeed, moveTime, cb, 16)
            })
        }

        // setInterval(() => {
        //     if (logData) {
        //         let date = new Date();
        //         dbConn.insert('data', {
        //             tm: date,
        //             sensor: JSON.stringify(SensorSystem.sensor.attributes),
        //             gps: JSON.stringify(SensorSystem.gps.attributes),
        //             //servo: '',
        //             signal: gsmSignal,
        //             logTm: logDate,
        //             gyroMode: gyroMode
        //         }, function (id, insertObj) {
        //             // console.log('insertObj', insertObj);
        //         })
        //     }

        // }, 1000);

        //require('node-cmd').run('echo 0 | sudo tee /sys/class/leds/led1/brightness');
        //require('node-cmd').run('sudo /bin/echo 0 > /sys/class/leds/orangepi:green:pwr/brightness');

        setTimeout(function () {
            // then do another async task
            callback(null, 'network and service');
        }, 100);
    }
], function (err, results) {
    console.log('Complete series', results);
    // results is equal to ['one','two']
});


