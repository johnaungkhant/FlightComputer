const Waypoints = require('../Waypoints.js');


Waypoints.init(function (wpData) {
    // console.log(Waypoints.nextWp());
    // console.log(Waypoints.nextWp());
    // console.log(Waypoints.nextWp());
    // console.log(Waypoints.nextWp());
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
    console.log(Waypoints.nextWp(true));
})