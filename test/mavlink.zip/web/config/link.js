var Backbone = require("backbone");

//import { SerialPort } from 'serialport'
const SerialPort = require("serialport").SerialPort;

//import { MavLinkPacketSplitter, MavLinkPacketParser } from 'node-mavlink'
const node_mavlink = require('node-mavlink');
const MavLinkPacketSplitter = node_mavlink.MavLinkPacketSplitter;
const MavLinkPacketParser = node_mavlink.MavLinkPacketParser;
const minimal = node_mavlink.minimal;
const common = node_mavlink.common;
const ardupilotmega = node_mavlink.ardupilotmega;
const waitFor = node_mavlink.waitFor;
const sleep = node_mavlink.sleep;

//import { MavLinkPacketSplitter, MavLinkPacketParser, minimal, common, ardupilotmega } from 'node-mavlink';
// create a registry of mappings between a message id and a data class
const REGISTRY = Object.assign(Object.assign(Object.assign({}, minimal.REGISTRY), common.REGISTRY), ardupilotmega.REGISTRY);

//for udp proxy
// require("./runMAVProxy.js")
// const reader = port = new node_mavlink.MavEsp8266()
// reader.start()
// MavLinkPacket = node_mavlink.MavLinkPacket
// const linkSend = function (port, cmd) {
//     port.send(cmd)
// }

//let serialPortPath = '/dev/ttyS1';
let serialPortPath = 'COM8';
//let serialPortPath = '/dev/serial0';

const port = new SerialPort({ path: serialPortPath, baudRate: 115200 });
const reader = port
    .pipe(new MavLinkPacketSplitter())
    .pipe(new MavLinkPacketParser())

const linkSend = node_mavlink.send

let waypointGen = {
    takeoff: function (alt) {
        return { cmd: 22, lat: 0, lon: 0, alt: alt, frame: 3 }
    },
    waypoint: function (alt, lat, lon) {
        return { cmd: 16, lat: lat, lon: lon, alt: alt, frame: 3 }
    },
    landing: function (alt, lat, lon) {
        return { cmd: 21, lat: lat, lon: lon, alt: alt, frame: 3 }
    }
}

let LinkConn = Backbone.Model.extend({

    defaults: {

    },
    online: false,
    initialize: function () {
        let self = this
        // constructing a reader that will emit each packet separately

        reader.on('data', packet => {
            try {
                this.online = true
                const clazz = REGISTRY[packet.header.msgid];
                if (clazz) {
                    const data = packet.protocol.data(packet.payload, clazz);
                    //console.log(data);
                    this.trigger(data.constructor.name, data)
                    self.processData(data);
                } else {
                    console.log(packet);
                }
            } catch (error) {
                console.log('err', error);
            }

        })
    },

    processData: function (data) {

        const dataName = data.constructor.name;

        if (dataName == "Heartbeat") {
            //console.log('Heartbeat', data)
            //console.log(data.customMode);
            this.set('customMode', data.customMode)
            this.set('baseMode', data.baseMode)

        } else if (dataName == 'StatusText') {
            console.log(data);
        } else if (dataName == 'GlobalPositionInt') {
            this.set('posInt', { lat: data.lat, lon: data.lon })
            this.set('alt', data.alt)
            this.set('relativeAlt', data.relativeAlt)

            //console.log(data);
        }
        else if (dataName == 'GpsRawInt') {
            this.set('posRawInt', { lat: data.lat, lon: data.lon })
            this.set('HDOP', data.eph)
            //console.log(data);
        } else if (dataName == 'ScaledPressure') {
            // console.log(data);
        }
        else if (dataName == 'VfrHud') {
            //airspeed, m/s
            //groundspeed, m/s
            //alt, m
            //climb, m/s
            //heading, deg
            //throttle %

            this.set(data)
        } else if (dataName == 'NavControllerOutput') {
            // console.log(data);
        }
        else if (dataName == 'ServoOutputRaw') {
            // if (this.stateObj.servo8Raw != data.servo8Raw) {
            //     stateObj.servo8Raw = data.servo8Raw
            //     console.log(data.servo8Raw);
            // }

        }
        else if (dataName == 'Attitude') {
            this.set('roll', data.roll)
            this.set('pitch', data.pitch)
            this.set('yaw', data.yaw)
        }
        else if (dataName == 'MissionAck') {
            console.log(data)
        }
        else if (dataName == 'CommandAck') {
            console.log(data)
        }
        else {
            // console.log(data)
        }

    },

    addWaypoint: async function (wayPointData) {

        await this.MissionCount(wayPointData.length)

        for (let index = 0; index < wayPointData.length; index++) {
            await sleep(500)
            const wayPointObj = wayPointData[index];
            await this.MissionItem(index, wayPointObj.cmd, wayPointObj.lat, wayPointObj.lon, wayPointObj.alt, wayPointObj.frame)
        }
        await sleep(1000)
        await this.MissionAck(0)
    },

    //MAVLink protocol
    RequestDataStream: async function (enable) {
        //REQUEST_DATA_STREAM
        const message = new common.RequestDataStream();
        message.reqMessageRate = 10;
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.startStop = enable ? 1 : 0;
        // message.reqStreamId = 93
        await linkSend(port, message);
    },
    MissionClearAll: async function () {
        //REQUEST_DATA_STREAM
        const message = new common.MissionClearAll();
        message.targetSystem = 1;
        message.targetComponent = 1;

        await linkSend(port, message);
    },
    MissionAck: async function (type) {
        //REQUEST_DATA_STREAM
        const message = new common.MissionAck();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.type = type
        await linkSend(port, message);
    },
    MissionCount: async function (count) {
        //REQUEST_DATA_STREAM
        const message = new common.MissionCount();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.count = count
        await linkSend(port, message);
    },

    MissionItem: async function (seq, cmd, x, y, z, frame, params) {
        //REQUEST_DATA_STREAM
        const message = new common.MissionItem();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.seq = seq;
        if (params) {

        } else {
            message.param1 = 0
            message.param2 = 0
            message.param3 = 0
            message.param4 = 0
        }

        message.x = x
        message.y = y
        message.z = z
        message.command = cmd
        message.frame = frame
        message.current = 0
        message.autocontinue = 1
        message.missionType = 0

        //console.log('send', message);
        //await  node_mavlink.sendSigned(port, message)
        await linkSend(port, message);// new node_mavlink.MavLinkProtocolV2()
    },

    MissionRequest: async function (seq, cb) {
        //REQUEST_DATA_STREAM
        const message = new common.MissionRequest();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.seq = seq
        //message.missionType = 0
        //await  node_mavlink.sendSigned(port, message)
        await linkSend(port, message);// new node_mavlink.MavLinkProtocolV2()
        this.once('MissionItem', function (data) {
            if (cb) cb(data)
        })
    },

    MissionRequestList: async function () {
        //REQUEST_DATA_STREAM
        const message = new common.MissionRequestList();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.missionType = 0
        //await  node_mavlink.sendSigned(port, message)
        await linkSend(port, message);// new node_mavlink.MavLinkProtocolV2()
    },

    MissionStart: async function () {
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.MISSION_START
        msg.targetSystem = 1;
        msg.targetComponent = 1;
        msg.param1 = 0
        msg.param2 = 0
        await linkSend(port, msg);
    },

    SetMode: async function (mode, cb) {
        //REQUEST_DATA_STREAM
        const message = new common.SetMode();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.customMode = mode
        message.baseMode = 1
        //.log();
        await linkSend(port, message);

        let setmodeCallback = (result) => {
            if (result.command == 11) {
                //console.log('SetMode', result);
                this.off('CommandAck', setmodeCallback)
                if (cb) cb(result.result)
            }
        }
        this.on('CommandAck', setmodeCallback)
    },

    Arming: async function (enable) {
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.COMPONENT_ARM_DISARM
        msg.targetSystem = 1;
        msg.targetComponent = 1;

        msg.param1 = enable ? 1 : 0
        //msg.param2 = 1
        await linkSend(port, msg)
        //await reader.send(msg)
    },

    doSetServo: async function (pin, pwm) {
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.DO_SET_SERVO
        msg.targetSystem = 1;
        msg.targetComponent = 1;

        msg.param1 = pin;
        msg.param2 = pwm;
        await linkSend(port, msg);
    },

})

let link = module.exports = new LinkConn()

// conn.on('Heartbeat', function (data) {
//     console.log(data);
// })

const customModeMap = {
    0: "Stabilize",
    1: "Acro",
    2: "AltHold",
    3: "Auto",
    4: "Guided",
    5: "Loiter",
    6: "RTL",
    7: "Circle",
    9: "Land",
    11: "Drift",
    13: "Sport",
    14: "Flip",
    15: "AutoTune",
    16: "PosHold",
    17: "Brake",
    18: "Throw",
    19: "Avoid_ADSB",
    20: "Guided_NoGPS",
    21: "Smart_RTL",
    22: "FlowHold",
    23: "Follow",
    24: "ZigZag",
    25: "SystemID",
    26: "Heli_Autorotate",
    27: "Auto RTL",
}

// link.on('change', function (event) {
//     for (const key in event.changed) {
//         if (Object.hasOwnProperty.call(event.changed, key)) {
//             let value = event.changed[key];
//             if (key == 'customMode') {
//                 value = customModeMap[value]

//             }
//             else if (key == 'HDOP') {
//                 ///console.log('change', key, value);
//             } else {
//                 continue;
//             }
//             console.log('change', key, value);
//         }
//     }
// })

// waitFor(function (result) {
//     // console.log('waitFor', result);

// })

async function main() {
    //  await waitFor(() => online)

    //3:auto
    //0: "Stabilize",
    //16: "PosHold",

    // link.once('Heartbeat', function (params) {
    //     console.log('arming');
    //     // setTimeout(() => {

    //     // link.SetMode(0, function (result) {
    //     //     //sleep(2000)

    //     //     // }, 1000);
    //     // })
    // })

    // link.RequestDataStream(false)
    // //link.arming(1)
    // setInterval(() => {
    //     link.MissionRequestList()
    // }, 1000);


    // await link.addWaypoint([
    //     waypointGen.waypoint(0, 8.6970325, 98.2410939),
    //     waypointGen.takeoff(20),
    //     waypointGen.waypoint(20, 8.6970391, 98.2411844,),
    //     waypointGen.landing(1, 8.69697420, 98.24110060)
    // ])

    // conn.MissionRequest(0, function (result) {
    //     console.log('result', result);
    // })
    //console.log(1.5 * 1e7);

}

//let wayPointData = []

//main()