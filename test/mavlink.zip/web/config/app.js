let _ = require("underscore");
async = require("async");

http = require('http');
nodeStatic = require('node-static');
file = new nodeStatic.Server(__dirname + '/web');

NwLib = require('./lib/NwLib.js');
Class = NwLib.Nwjsface.Class;

// nwHttpConn = require('./nwHttpConn.js');

NwWsServer = require('./NwWsServer.js');
NwServiceProcess = require('./NwServiceProcess.js');
NwServiceMethod = require('./NwServiceMethod.js');

//------------------------------------------------------------------------

NwWsClient = require('./web/NwWsClient.js');

// // wsClient = new NwWsClient("http://newww.duckdns.org");
// wsClient = new NwWsClient("http://rutapon.totddns.com:37900");
// // wsClient = new NwWsClient("http://newwwnode.herokuapp.com");
// //wsClient = new NwWsClient("http://autovs.herokuapp.com");
// //wsClient = new NwWsClient("http://192.168.43.1");
// deviceId = null
// require('systeminformation').blockDevices(function (data) {
//     deviceId = data[0].serial;

//     deviceId = require('crypto').createHash('sha256').update(deviceId + "'").digest('base64url')
//     console.log(deviceId);
// })

// wsClient.setOnConnectEventListener(function (socket) {
//     var id = wsClient.getId();
//     console.log('onConnect setOnConnectEventListener' + id);

//     wsClient.callService('reg_node', { sid: id, did: deviceId }, function (resultData) {
//         console.log('resultData', resultData);
//         // cb(resultData)
//     });

//     // wsClient.callService('getServerDateTime', null, function (result) {
//     //     console.log(result);
//     // })
// });

// wsClient.setOnMessageEventListener(function (socket, msgObj, fn) {
//     // console.log('OnMessage', msgObj, wsClient.getId());

//     NwServiceProcess.cammandProcess(msgObj, function (result) {
//         //console.log(result);
//         fn(result);
//     });
// })

// wsClient.setOnDisconnectEventListener(function () {
//     console.log('wsClient Disconnect');
// });

//------------------------------------------------------------------------

var port = 80
var httpConn = null;
var espColl = null;

var wsServer = null;

var passiveConn = function (appServer, httpConn, espColl) {
    var self = this;

    wsServer = new NwWsServer(appServer);

    NwServiceMethod.addNwWsServer(wsServer, httpConn, espColl);

    NwServiceProcess.addServiceMethod(NwServiceMethod);


    wsServer.setOnConnectEventListener(function (socket) {
        console.log('OnConnectEventListener ' + socket.id);

    });

    wsServer.setOnDisconnectEventListener(function (socket) {
        console.log('OnDisconnectEventListener');
    });


    wsServer.setOnMessageEventListener(function (socket, msgObj, fn) {
        NwServiceProcess.cammandProcess(msgObj, function (result) {
            //console.log(result);

            // console.log(result);
            fn(result);
        });
    });
}

var listenCommand = function (commandPort) {
    this.commandPort = commandPort;

    //var httpServer = http.createServer(app);
    var appServer = http.createServer(function (request, response) {
        request.addListener('end', function () {
            //
            // Serve files!
            //
            file.serve(request, response);
        }).resume();
    });

    passiveConn(appServer, httpConn, espColl);

    appServer.listen(commandPort);
}

listenCommand(port);

console.log('Start App newww');

//===================================================================================
//const mvLink = require('./link.js')
const SystemConfig = require("./driver/SystemConfig.js")

let gsmSignal = null;

function getGsmSignalQuery(sid, cb) {

    let postStrUrl = "http://192.168.100.1/api/json"

    require('request').post({
        url: postStrUrl,
        "headers": {
            "accept": "application/json, text/plain, */*",
            "accept-language": "en,en-US;q=0.9,th;q=0.8,zh-CN;q=0.7,zh;q=0.6",
            "authorization": "54ad2aa0-7238-42c6-90fc-6a4fd8b4eb00",
            "content-type": "application/json;charset=UTF-8",
            "cookie": "size=default; sidebarStatus=0",
            "Referer": "http://192.168.100.1/",
            "Referrer-Policy": "strict-origin-when-cross-origin"
        },
        "body": "{\"fid\":\"queryFields\",\"fields\":{\"signalStrength\":-200},\"sessionId\":\"" + sid + "\"}",

    }, function (err, httpResponse, body) {
        //console.log(JSON.parse(body).data.signal);
        // cb(JSON.parse(body).data.signal)
        // console.log(err);
        cb(body)
    });

}

function getGsmSignalLogin(cb) {

    let postStrUrl = "http://192.168.100.1/api/json"

    require('request').post({
        url: postStrUrl,
        "headers": {
            "accept": "application/json, text/plain, */*",
            "accept-language": "en,en-US;q=0.9,th;q=0.8,zh-CN;q=0.7,zh;q=0.6",
            "authorization": "",
            "content-type": "application/json;charset=UTF-8",
            "cookie": "size=default; sidebarStatus=0",
            "Referer": "http://192.168.100.1/",
            "Referrer-Policy": "strict-origin-when-cross-origin"
        },
        "body": "{\"fid\":\"login\",\"username\":\"\",\"password\":\"123456789#a\",\"sessionId\":\"\"}",

    }, function (err, httpResponse, body) {
        //console.log(JSON.parse(body).data.signal);
        // cb(JSON.parse(body).data.signal)
        // console.log(httpResponse);
        cb(body)
    });

}

function getGsmSignal(cb) {
    getGsmSignalLogin(function (body) {
        // console.log(JSON.parse(body).session);
        if (body)
            getGsmSignalQuery(JSON.parse(body).session, function (result) {
                if (result)
                    cb(JSON.parse(result).fields.signalStrength)
                else
                    cb(null)
            })
        else {
            cb(null)
        }
    })
}

var getSignalRecur = function () {
    getGsmSignal(function (result) {
        // console.log(result);
        gsmSignal = result;
        setTimeout(getSignalRecur, 1500);
    })
}

//getSignalRecur()

NwServiceProcess.cmdMethod['getInfo'] = function (data, cb) {
    cb({
        gps: { lat: 8.6970325, lon: 98.2410939 },
        now: new Date()
    })
}

NwServiceProcess.cmdMethod['getMapPositionData'] = function (data, cb) {
    // console.log('getInfo');
    cb({
        gps: SensorSystem.gps,
        status: {
            signal: gsmSignal,
            logData: logData
        },

    })
}

NwServiceProcess.cmdMethod['getWpData'] = function (data, cb) {
    // console.log('getInfo');
    const Waypoints = require('../../modules/Waypoints.js');
    Waypoints.init(function () {
        self.set('currentTarget', Waypoints.nextWp(true))  // { lat: 7.88477600, lon: 98.38915320 };
        self.set('wpData', Waypoints.wpData)

        self.updateTarget() // use home (id 0) as starting point and set target to id 1 
    })
    cb(ActionControl.PositionControl.get('wpData'))
}

let dbConn = require("./driver/sqliteConn.js");
//const PositionControl = require("./control/ActionControl/PositionControl.js");
dbConn.dbPath = "./data/infodata.db"

let logData = false;
let logDate = null
NwServiceProcess.cmdMethod['logDataState'] = function (data, cb) {
    //console.log('logDataState', data);
    if (data != null) {
        logData = data;
        if (logData) {
            logDate = new Date()
        }
    }
    cb(logData)
}

// setInterval(() => {
//     if (logData) {
//         let date = new Date();
//         dbConn.insert('data', {
//             tm: date,
//             sensor: JSON.stringify(SensorSystem.sensor.attributes),
//             gps: JSON.stringify(SensorSystem.gps.attributes),
//             //servo: '',
//             signal: gsmSignal,
//             logTm: logDate,
//             gyroMode: gyroMode
//         }, function (id, insertObj) {
//             // console.log('insertObj', insertObj);
//         })
//     }

// }, 1000);