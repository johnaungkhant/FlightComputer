var cmd = require('node-cmd');
require('node-cmd').run("echo host > /sys/kernel/debug/usb/ci_hdrc.0/role");
let currentDrive = null
setInterval(() => {
    cmd.run('ls /dev/sd*', function (err, data, stderr) {

        if (data && data.indexOf('/dev/sd') == 0) {
            let drivePath = data.split('\n')[0] + '1'
            //console.log(drivePath);
            if (drivePath != currentDrive) {

                //require('node-cmd').run('sudo umount -f /dev/sda1');

                cmd.run('sudo mount ' + drivePath + ' /data', function (err, data, stderr) {
                    if (stderr.indexOf('already mounted on /data.' > 0)) {
                        currentDrive = drivePath
                    }
                    console.log('mount', drivePath, data, stderr);
                })
            } else {

            }
        } else {
            console.log('no usb devise');
        }
    });

}, 1000);