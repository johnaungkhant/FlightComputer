
const node_mavlink = require('node-mavlink');

const common = node_mavlink.common;

const mavlink_1 = require("mavlink-mappings");// node_mavlink.mavlink
// class LogRequestData extends mavlink_1.MavLinkData {
// }

// LogRequestData.MSG_ID = 119;
// LogRequestData.MSG_NAME = 'LOG_REQUEST_DATA';
// LogRequestData.PAYLOAD_LENGTH = 12;
// LogRequestData.MAGIC_NUMBER = 116;
// LogRequestData.FIELDS = [
//     new mavlink_1.MavLinkPacketField('ofs', 'ofs', 0, false, 4, 'uint32_t', ''),
//     new mavlink_1.MavLinkPacketField('count', 'count', 4, false, 4, 'uint32_t', 'bytes'),
//     new mavlink_1.MavLinkPacketField('id', 'id', 8, false, 2, 'uint16_t', ''),
//     new mavlink_1.MavLinkPacketField('target_system', 'targetSystem', 10, false, 1, 'uint8_t', ''),
//     new mavlink_1.MavLinkPacketField('target_component', 'targetComponent', 11, false, 1, 'uint8_t', ''),
// ];

class RallyFetchPoint extends mavlink_1.MavLinkData {
}
common.RallyFetchPoint = RallyFetchPoint;
RallyFetchPoint.MSG_ID = 176;
RallyFetchPoint.MSG_NAME = 'RALLY_FETCH_POINT';
RallyFetchPoint.PAYLOAD_LENGTH = 3;
RallyFetchPoint.MAGIC_NUMBER = 234;
RallyFetchPoint.FIELDS = [
    new mavlink_1.MavLinkPacketField('target_system', 'targetSystem', 0, false, 1, 'uint8_t', ''),
    new mavlink_1.MavLinkPacketField('target_component', 'targetComponent', 1, false, 1, 'uint8_t', ''),
    new mavlink_1.MavLinkPacketField('idx', 'idx', 2, false, 1, 'uint8_t', ''),
];

class RallyPoint extends mavlink_1.MavLinkData {
}
common.RallyPoint = RallyPoint;
RallyPoint.MSG_ID = 175;
RallyPoint.MSG_NAME = 'RALLY_POINT';
RallyPoint.PAYLOAD_LENGTH = 19;
RallyPoint.MAGIC_NUMBER = 138;
RallyPoint.FIELDS = [
    new mavlink_1.MavLinkPacketField('lat', 'lat', 0, false, 4, 'int32_t', 'degE7'),
    new mavlink_1.MavLinkPacketField('lon', 'lon', 4, false, 4, 'int32_t', 'degE7'),
    new mavlink_1.MavLinkPacketField('alt', 'alt', 8, false, 2, 'int16_t', 'mm'),
    new mavlink_1.MavLinkPacketField('break_alt', 'breakAlt', 10, false, 2, 'int16_t', 'mm'),
    new mavlink_1.MavLinkPacketField('land_dir', 'landDir', 12, false, 2, 'uint16_t', ''),
    new mavlink_1.MavLinkPacketField('target_system', 'targetSystem', 14, false, 1, 'uint8_t', ''),
    new mavlink_1.MavLinkPacketField('target_component', 'targetComponent', 15, false, 1, 'uint8_t', ''),
    new mavlink_1.MavLinkPacketField('idx', 'idx', 16, false, 1, 'uint8_t', ''),
    new mavlink_1.MavLinkPacketField('count', 'count', 17, false, 1, 'uint8_t', ''),
    new mavlink_1.MavLinkPacketField('flags', 'flags', 18, false, 1, 'uint8_t', '')
];

common.REGISTRY[175] = RallyPoint
common.REGISTRY[176] = RallyFetchPoint

