var cmd = require('node-cmd');
cmd.run('sudo /bin/echo 0 > /sys/class/leds/red:os/brightness'); //open stick
let lightOn = function (isOn) {
    if (isOn) {
        //cmd.run('sudo /bin/echo 1 > /sys/class/leds/led0/brightness');
        //cmd.run('echo 1 | sudo tee /sys/class/leds/led0/brightness');
        //cmd.run('sudo /bin/echo 1 > /sys/class/leds/orangepi:green:pwr/brightness');//orange pi
        //cmd.run('opio write 126 1') i96
        //cmd.run('sudo /bin/echo 0 > /sys/class/leds/bananapi-m2-zero:red:pwr/brightness'); //banana pi zero
        cmd.run('sudo /bin/echo 1 > /sys/class/leds/green:internet/brightness'); //open stick
        cmd.run('sudo gpioset gpiochip0 83=1'); //open stick 2
    } else {
        //cmd.run('echo 0 | sudo tee /sys/class/leds/led0/brightness');
        //cmd.run('sudo /bin/echo 0 > /sys/class/leds/orangepi:green:pwr/brightness');//orange pi
        //cmd.run('opio write 126 0')i96
        //cmd.run('sudo /bin/echo 1 > /sys/class/leds/bananapi-m2-zero:red:pwr/brightness'); //banana pi zero
       cmd.run('sudo /bin/echo 0 > /sys/class/leds/green:internet/brightness'); //open stick
        cmd.run('sudo gpioset gpiochip0 83=0'); //open stick 2
    }
}
var OnbordLed = {}
OnbordLed.blink = function (timeInterval, onTime) {
    if (timeInterval == 0) {
        this.stop()
        return
    }

    if (this.blinkOnbordLedInterval) clearInterval(this.blinkOnbordLedInterval)

    var on = true;
    this.blinkOnbordLedInterval = setInterval(() => {
        if (onTime) {
            lightOn(true)
            setTimeout(() => {
                lightOn(false)
            }, onTime);
        } else {
            on = !on;
            lightOn(on)
        }
    }, timeInterval);
}

OnbordLed.stop = function () {
    if (this.blinkOnbordLedInterval) clearInterval(this.blinkOnbordLedInterval)
    lightOn(false)
}

module.exports = OnbordLed