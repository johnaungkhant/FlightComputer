const Backbone = require("backbone");
const async = require("async");

//import { SerialPort } from 'serialport'
//const SerialPort = require("serialport").SerialPort;

//import { MavLinkPacketSplitter, MavLinkPacketParser } from 'node-mavlink'
const node_mavlink = require('node-mavlink');
const MavLinkPacketSplitter = node_mavlink.MavLinkPacketSplitter;
const MavLinkPacketParser = node_mavlink.MavLinkPacketParser;
const minimal = node_mavlink.minimal;
const common = node_mavlink.common;
const ardupilotmega = node_mavlink.ardupilotmega;
const waitFor = node_mavlink.waitFor;
const sleep = node_mavlink.sleep;
const MavLinkProtocolV1 = node_mavlink.MavLinkProtocolV1;

// require("./mavlinkCommonExtension.js")
// console.log(common.REGISTRY[175]);
//import { MavLinkPacketSplitter, MavLinkPacketParser, minimal, common, ardupilotmega } from 'node-mavlink';
// create a registry of mappings between a message id and a data class
const REGISTRY = Object.assign(Object.assign(Object.assign({}, minimal.REGISTRY), common.REGISTRY), ardupilotmega.REGISTRY);

node_mavlink.MavLinkProtocol.SYS_ID = 255

//const port = new SerialPort({ path: serialPortPath, baudRate: 115200 });//115200

var usb = require('usb');
var UsbCdcAcm = require('usb-cdc-acm');

var device = usb.findByIds(0x2341, 0x0010); // VID/PID for Nordic Semi / USB CDC demo

// The device MUST be open before instantiating the UsbCdcAcm stream!

device.open();

// An options object with the baud rate is optional.
let port = UsbCdcAcm.fromUsbDevice(device, { baudRate: 115200 });
//const port = new SerialPort(stream);//115200

const reader = port
    .pipe(new MavLinkPacketSplitter())
    .pipe(new MavLinkPacketParser())


node_mavlink.MavLinkProtocol.SYS_ID = 255

// listen for messages from the parent process
process.on("message", message => {
    // let isPrime = checkIfPrime(message);
    // // send the results back to the parent process
    // process.send(isPrime);
    // // kill the child process
    // process.exit();

    // if (message.type == 'linkSend') {
    //     console.log('message', message.message);
    //     node_mavlink.send(port, message.message)
    // }

    // console.log(message);

    let classType = common[message.type]
    let msgObj = new classType()

    for (const key in message.message) {
        if (Object.hasOwnProperty.call(message.message, key)) {
            const element = message.message[key];
            msgObj[key] = element
        }
    }
    // console.log(msgObj);

    node_mavlink.send(port, msgObj)
    //console.log('form child', message);
})
var cleanExit = function () {
    console.log('Sensor process.exit()');
    process.exit()
};
process.on('SIGINT', cleanExit); // catch ctrl-c
process.on('SIGTERM', cleanExit); // catch kill
process.on('exit', cleanExit); // catch exit


BigInt.prototype.toJSON = function () {
    return this.toString()
}

reader.on('data', packet => {
    try {
        this.online = true

        const clazz = REGISTRY[packet.header.msgid];
        if (clazz) {
            const data = packet.protocol.data(packet.payload, clazz);
            //console.log(data);
            // this.trigger(data.constructor.name, data)
            // self.processData(data);

            process.send({
                type: data.constructor.name,
                data: data
            });

        } else {
            console.log('registry err', packet);
        }
    } catch (error) {
        console.log('err', error);
    }

})