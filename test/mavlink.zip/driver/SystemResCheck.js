let SystemResConfig = require('./SystemResConfig.json')
//let coder = require('country-coder')
let iso1A2Code = require('@ideditor/country-coder').iso1A2Code;

var SystemResCheck = {}

function rangeFromCurrent(lat, lon, currentLat, currentLon) {

}

let checkReg = SystemResCheck.checkReg = function (lat, lon) {
    //return coder.feature([-12.3, -37.1]).properties.iso1A2
    return iso1A2Code([lon, lat])
}

SystemResCheck.locationCheck = function (lat, lon, currentLat, currentLon) {
    //check for region/country
    let result = checkReg(lat, lon) == SystemResConfig['targetReg']

    if (!result) {
        //check for range
        let range = rangeFromCurrent(lat, lon, currentLat, currentLon)
        result = range < SystemResConfig['outside_targetReg_range']
    }
}

SystemResCheck.expireDateCheck = function (currentDateISOStr) {
    return currentDateISOStr > SystemResConfig['expire_date']
}

const GPS = require('gps');
SystemResCheck.distanceCheck = function (currentPos, pointArray) {
    let currentReg = checkReg(currentPos.lat, currentPos.lon)

    // console.log('pointReg', pointArray);
    // console.log('currentReg', currentReg);

    let sameReg = true
    for (let index = 0; index < pointArray.length; index++) {
        const point = pointArray[index];
        let pointReg = checkReg(point.lat, point.lon)

        if (pointReg != currentReg) {
            sameReg = false
            break;
        }
    }

    if (sameReg) {

        if (currentReg == SystemResConfig['targetReg']) {
            // infinite distance
            return true
        } else {
            let limitRange = SystemResConfig['outside_targetReg_range']

            // console.log('limitRange', limitRange);
            let inRangeDistance = true
            for (let index = 0; index < pointArray.length; index++) {
                const point = pointArray[index];

                // GPS.Distance(latFrom, lonFrom, latTo, lonTo)
                let pointDist = GPS.Distance(currentPos.lat, currentPos.lon, point.lat, point.lon) * 1000
                // console.log('pointDist', pointDist);
                if (pointDist > limitRange) {
                    inRangeDistance = false
                    break;
                }
            }

            return inRangeDistance
        }

    } else {
        // do not permit cross reg flight
        return false
    }
}

module.exports = SystemResCheck

// let timeoutHandle = setTimeout(() => {
//     console.log(checkReg(7.69713060, 98.24120390));//lon,lat
//     clearTimeout(timeoutHandle)
// }, 2000);
