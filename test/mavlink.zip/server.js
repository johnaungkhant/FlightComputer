
//require('node-cmd').run("echo gadget  > /sys/kernel/debug/usb/ci_hdrc.0/role");
// require('node-cmd').run("echo host > /sys/kernel/debug/usb/ci_hdrc.0/role");
// require('./service/autoMount.js')

let _ = require("underscore");
async = require("async");

http = require('http');
nodeStatic = require('node-static');
path = require('path');
file = new nodeStatic.Server(path.resolve(__dirname + '/web'));
fileMapData = new nodeStatic.Server(path.resolve('/data'));

NwLib = require('./lib/NwLib.js');
Class = NwLib.Nwjsface.Class;

// nwHttpConn = require('./nwHttpConn.js');

NwWsServer = require('./NwWsServer.js');
NwServiceProcess = require('./NwServiceProcess.js');
NwServiceMethod = require('./NwServiceMethod.js');

//------------------------------------------------------------------------

NwWsClient = require('./web/NwWsClient.js');

// // wsClient = new NwWsClient("http://newww.duckdns.org");
// wsClient = new NwWsClient("http://rutapon.totddns.com:37900");
// // wsClient = new NwWsClient("http://newwwnode.herokuapp.com");
// //wsClient = new NwWsClient("http://autovs.herokuapp.com");
// //wsClient = new NwWsClient("http://192.168.43.1");
// deviceId = null
// require('systeminformation').blockDevices(function (data) {
//     deviceId = data[0].serial;

//     deviceId = require('crypto').createHash('sha256').update(deviceId + "'").digest('base64url')
//     console.log(deviceId);
// })

// wsClient.setOnConnectEventListener(function (socket) {
//     var id = wsClient.getId();
//     console.log('onConnect setOnConnectEventListener' + id);

//     wsClient.callService('reg_node', { sid: id, did: deviceId }, function (resultData) {
//         console.log('resultData', resultData);
//         // cb(resultData)
//     });

//     // wsClient.callService('getServerDateTime', null, function (result) {
//     //     console.log(result);
//     // })
// });

// wsClient.setOnMessageEventListener(function (socket, msgObj, fn) {
//     // console.log('OnMessage', msgObj, wsClient.getId());

//     NwServiceProcess.cammandProcess(msgObj, function (result) {
//         //console.log(result);
//         fn(result);
//     });
// })

// wsClient.setOnDisconnectEventListener(function () {
//     console.log('wsClient Disconnect');
// });

//------------------------------------------------------------------------

var port = 80
var httpConn = null;
var espColl = null;

var wsServer = null;

let led = require('./driver/OnbordLed.js')
led.blink(1000)

var passiveConn = function (appServer, httpConn, espColl) {
    var self = this;

    wsServer = new NwWsServer(appServer);

    NwServiceMethod.addNwWsServer(wsServer, httpConn, espColl);

    NwServiceProcess.addServiceMethod(NwServiceMethod);


    wsServer.setOnConnectEventListener(function (socket) {
        console.log('OnConnectEventListener ' + socket.id);
        //led.stop()
        led.blink(100)
        //withoutRemote = true
    });

    wsServer.setOnDisconnectEventListener(function (socket) {
        console.log('OnDisconnectEventListener');
        led.blink(1000)
    });


    wsServer.setOnMessageEventListener(function (socket, msgObj, fn) {
        NwServiceProcess.cammandProcess(msgObj, function (result) {
            //console.log(result);

            // console.log(result);
            fn(result);
        });
    });
}

var listenCommand = function (commandPort) {
    this.commandPort = commandPort;

    //var httpServer = http.createServer(app);
    var appServer = http.createServer(function (request, response) {
        //console.log(request.method, request.url);
        request.addListener('end', function () {
            //
            // Serve files!
            //
            if (request.method == 'GET' && request.url.indexOf('/MapData/') == 0) {
                //console.log('mapdata');
                fileMapData.serve(request, response);
            } else {
                file.serve(request, response);
            }

        }).resume();
    });

    passiveConn(appServer, httpConn, espColl);

    appServer.listen(commandPort);
}

listenCommand(port);

console.log('Start App newww');


// require('request').get("https://www.duckdns.org/update?domains=newww&token=1c7c011a-c53e-40db-bd12-df8e74a4a326", function (err, resp, body) {
//     console.log('resp', body);
// });