let NwMvLinkServiceMethod = function (NwServiceProcess, mvLink) {
    console.log('MvLinkServiceMethod');
}
module.exports = NwMvLinkServiceMethod;