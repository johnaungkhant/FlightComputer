const Backbone = require("backbone");
const async = require("async");

//import { SerialPort } from 'serialport'
//const SerialPort = require("serialport").SerialPort;

//import { MavLinkPacketSplitter, MavLinkPacketParser } from 'node-mavlink'
const node_mavlink = require('node-mavlink');
const MavLinkPacketSplitter = node_mavlink.MavLinkPacketSplitter;
const MavLinkPacketParser = node_mavlink.MavLinkPacketParser;
const minimal = node_mavlink.minimal;
const common = node_mavlink.common;
const ardupilotmega = node_mavlink.ardupilotmega;
const waitFor = node_mavlink.waitFor;
const sleep = node_mavlink.sleep;
const MavLinkProtocolV1 = node_mavlink.MavLinkProtocolV1;


//import { MavLinkPacketSplitter, MavLinkPacketParser, minimal, common, ardupilotmega } from 'node-mavlink';
// create a registry of mappings between a message id and a data class
// const REGISTRY = Object.assign(Object.assign(Object.assign({}, minimal.REGISTRY), common.REGISTRY), ardupilotmega.REGISTRY);

// require("./driver/mavlinkCommonExtension.js")

node_mavlink.MavLinkProtocol.SYS_ID = 255

const childProcess = require('child_process')

let child_process = null

// let waypointGen = {
//     takeoff: function (alt) {
//         return { cmd: 22, lat: 0, lon: 0, alt: alt, frame: 3 }
//     },
//     waypoint: function (alt, lat, lon) {
//         return { cmd: 16, lat: lat, lon: lon, alt: alt, frame: 3 }
//     },
//     landing: function (alt, lat, lon) {
//         return { cmd: 21, lat: lat, lon: lon, alt: alt, frame: 3 }
//     }
// }

let MvLink = Backbone.Model.extend({

    defaults: {

    },
    online: false,
    initialize: function () {
        let self = this
        // constructing a reader that will emit each packet separately

        // reader.on('data', packet => {
        //     try {
        //         this.online = true
        //         const clazz = REGISTRY[packet.header.msgid];
        //         if (clazz) {
        //             const data = packet.protocol.data(packet.payload, clazz);
        //             //console.log(data);
        //             this.trigger(data.constructor.name, data)
        //             self.processData(data);
        //         } else {
        //             console.log(packet);
        //         }
        //     } catch (error) {
        //         console.log('err', error);
        //     }

        // })

        function restartUsb(cb) {
            console.log('try to restart usb');
            require('node-cmd').run("echo gadget  > /sys/kernel/debug/usb/ci_hdrc.0/role");
            setTimeout(() => {
                require('node-cmd').run("echo host > /sys/kernel/debug/usb/ci_hdrc.0/role");
                setTimeout(() => {
                    if (cb) cb()
                }, 2000);
            }, 1000);
        }

        let restartSecCount = 0
        var startSensor = function () {
            console.log('start usbCDCProcess');

            child_process = childProcess.fork(__dirname + '/driver/usbCDCProcess.js');
            let tryResartUsb = false
            //check for online
            let restartUsbHandle = setTimeout(() => {
                let isOnline = self.get('online')
                console.log('check for online', isOnline);
                if (!isOnline) {
                    tryResartUsb = true
                    child_process.kill()
                }
            }, 5000);

            child_process.on('exit', function (error) {
                console.log("usbMvLink exit here with exit: ", error);
                //if (exitCb) exitCb()
                clearTimeout(restartUsbHandle)
                self.set('online', false)

                restartSecCount++

                if (tryResartUsb || restartSecCount > 3) {
                    restartSecCount = 0
                    restartUsb(function () {
                        startSensor()
                    })
                } else {
                    setTimeout(() => {
                        startSensor()
                    }, 1000);
                }

            });

            child_process.on("message", result => {
                restartSecCount = 0
                self.set('online', true)

                self.trigger(result.type, result.data)
                self.processData(result.type, result.data);
            });

        }

        startSensor()
    },

    linkSend: async function (message) {

        if (child_process) {
            if (child_process.connected && this.attributes.online) {
                try {
                    child_process.send({ type: message.constructor.name, message: message })
                    return;
                } catch (error) {
                    console.log('linkSend error', error);
                }
            } else {
                //console.log('Sensor_child_process.connected', child_process.connected, this.attributes.online);
            }
        }
    },
    processData: function (dataName, data) {

        if (dataName == "Heartbeat") {

            // Heartbeat Heartbeat {
            //     customMode: 3,
            //     type: 2,
            //     autopilot: 3,
            //     baseMode: 89,
            //     systemStatus: 3,
            //     mavlinkVersion: 3
            //   }

            //console.log('Heartbeat', data)
            //console.log(data.customMode);
            this.set('customMode', data.customMode)
            this.set('baseMode', data.baseMode)

        } else if (dataName == 'StatusText') {
            console.log(data);
        } else if (dataName == 'GlobalPositionInt') {
            // GlobalPositionInt {
            //     timeBootMs: 741590,
            //     lat: 0,
            //     lon: 0,
            //     alt: -17000,
            //     relativeAlt: -1440,
            //     vx: 0,
            //     vy: 0,
            //     vz: 0,
            //     hdg: 30586
            //   }
            this.set('posInt', { lat: data.lat, lon: data.lon })
            this.set('alt', data.alt)
            this.set('relativeAlt', data.relativeAlt)

            //console.log(data);
        }
        else if (dataName == 'GpsRawInt') {
            // GpsRawInt {
            //     timeUsec: 0n,
            //     lat: 0,
            //     lon: 0,
            //     alt: -17000,
            //     eph: 9999,
            //     epv: 65535,
            //     vel: 0,
            //     cog: 0,
            //     fixType: 1,
            //     satellitesVisible: 0,
            //     altEllipsoid: 0,
            //     hAcc: 0,
            //     vAcc: 0,
            //     velAcc: 0,
            //     hdgAcc: 0,
            //     yaw: 0
            //   }
            this.set('posRawInt', { lat: data.lat, lon: data.lon })
            this.set('hdop', data.eph)
            //this.set('timeUsec', data.timeUsec)

            //console.log(data);
            //console.log('pos', { lat: data.lat, lon: data.lon });
        } else if (dataName == 'ScaledPressure') {
            // ScaledPressure {
            //     timeBootMs: 1572789,
            //     pressAbs: 1010.278564453125,
            //     pressDiff: 0.3246093690395355,
            //     temperature: 3597,
            //     temperaturePressDiff: 0
            //   }

            //console.log(data);
        } else if (dataName == 'VfrHud') {
            //airspeed, m/s
            //groundspeed, m/s
            //alt, m
            //climb, m/s
            //heading, deg
            //throttle %

            this.set(data)
            //console.log(data);
        } else if (dataName == 'NavControllerOutput') {
            // NavControllerOutput {
            //     navRoll: 0,
            //     navPitch: 0,
            //     altError: 0,
            //     aspdError: 0,
            //     xtrackError: 0,
            //     navBearing: 305,
            //     targetBearing: 0,
            //     wpDist: 0
            //   }

            //console.log(data);
            this.set('wpDist', data.wpDist)
        }
        else if (dataName == 'ServoOutputRaw') {
            // ServoOutputRaw {
            //     timeUsec: 1572810088,
            //     servo1Raw: 999,
            //     servo2Raw: 999,
            //     servo3Raw: 999,
            //     servo4Raw: 999,
            //     servo5Raw: 32767,
            //     servo6Raw: 32767,
            //     servo7Raw: 32767,
            //     servo8Raw: 1000,
            //     port: 0,
            //     servo9Raw: 0,
            //     servo10Raw: 0,
            //     servo11Raw: 0,
            //     servo12Raw: 0,
            //     servo13Raw: 0,
            //     servo14Raw: 0,
            //     servo15Raw: 0,
            //     servo16Raw: 0
            //   }
            //this.set('servo8Raw', data.servo8Raw)
            //console.log(data);
        }
        else if (dataName == 'Attitude') {
            // Attitude {
            //     timeBootMs: 1572810,
            //     roll: 0.036526355892419815,
            //     pitch: -0.033109262585639954,
            //     yaw: -0.9457555413246155,
            //     rollspeed: -0.0020592641085386276,
            //     pitchspeed: -0.0035544950515031815,
            //     yawspeed: -0.00021284446120262146
            //   }
            this.set('roll', data.roll)
            this.set('pitch', data.pitch)
            this.set('yaw', data.yaw)
            //console.log(data);
        }
        else if (dataName == 'RawImu') {
            // RawImu {
            //     timeUsec: 741559655n,
            //     xacc: -7,
            //     yacc: 18,
            //     zacc: -998,
            //     xgyro: 0,
            //     ygyro: -4,
            //     zgyro: -1,
            //     xmag: 156,
            //     ymag: 212,
            //     zmag: 34,
            //     id: 0,
            //     temperature: 0
            //   }
        }
        else if (dataName == 'RcChannelsRaw') {
            // RcChannelsRaw {
            //     timeBootMs: 741469,
            //     chan1Raw: 1501,
            //     chan2Raw: 1500,
            //     chan3Raw: 900,
            //     chan4Raw: 1500,
            //     chan5Raw: 1555,
            //     chan6Raw: 1499,
            //     chan7Raw: 1499,
            //     chan8Raw: 1500,nod
            //     port: 0,
            //     rssi: 0
            //   }
            //console.log(data.chan2Raw,data.chan3Raw);

            this.set('chan8Raw', data.chan8Raw)
            this.set('chan2Raw', data.chan2Raw)
            this.set('chan3Raw', data.chan3Raw)

            this.set('chServoCon', data.chan6Raw > 1500)
        }
        else if (dataName == 'Ahrs') {
            // Ahrs {
            //     omegaIx: 0.0013206477742642164,
            //     omegaIy: 0.0034318475518375635,
            //     omegaIz: 0.00027965992921963334,
            //     accelWeight: 0,
            //     renormVal: 0,
            //     errorRp: 0.0009030818473547697,
            //     errorYaw: 0.017257610335946083
            //   }
        }
        else if (dataName == 'SensorOffsets') {
            // SensorOffsets {
            //     magDeclination: 0,
            //     rawPress: 101007,
            //     rawTemp: 3485,
            //     gyroCalX: 0.011637239716947079,
            //     gyroCalY: -0.011344578117132187,
            //     gyroCalZ: -0.014686228707432747,
            //     accelCalX: 0.11140401661396027,
            //     accelCalY: 0.057300176471471786,
            //     accelCalZ: 0.5820214748382568,
            //     magOfsX: 143,
            //     magOfsY: -8,
            //     magOfsZ: 112
            //   }
        } else if (dataName == 'SysStatus') {
            // SysStatus {
            //     onboardControlSensorsPresent: 2227247,
            //     onboardControlSensorsEnabled: 2227247,
            //     onboardControlSensorsHealth: 2227247,
            //     load: 718,
            //     voltageBattery: 0,
            //     currentBattery: -1,
            //     dropRateComm: 0,
            //     errorsComm: 0,
            //     errorsCount1: 0,
            //     errorsCount2: 0,
            //     errorsCount3: 0,
            //     errorsCount4: 0,
            //     batteryRemaining: -1,
            //     onboardControlSensorsPresentExtended: 0,
            //     onboardControlSensorsEnabledExtended: 0,
            //     onboardControlSensorsHealthExtended: 0
            //   }
            this.set('voltageBattery', data.voltageBattery)
            this.set('currentBattery', data.currentBattery)
            this.set('batteryRemaining', data.batteryRemaining)

            //console.log('voltageBattery', data.voltageBattery / 1000, data.batteryRemaining,data.currentBattery);
        }
        else if (dataName == 'MemInfo') {
            // MemInfo { brkval: 7175, freemem: 989, freemem32: 0 }
        }
        else if (dataName == 'HwStatus') {
            //HwStatus { Vcc: 4693, I2Cerr: 0 }
        }
        else if (dataName == 'SystemTime') {
            //SystemTime { timeUnixUsec: 0n, timeBootMs: 1572830 }
            this.set('timeUnixUsec', data.timeUnixUsec)
            //console.log(data);
        }
        else if (dataName == 'MissionAck') {
            if (data.result != 0) console.log(data)

            console.log(data)
        }
        else if (dataName == 'CommandAck') {
            if (data.result != 0) console.log(data)

            console.log(data)
        }
        else if (dataName == 'MissionRequest') {

            console.log(data)
        }
        else if (dataName == 'MissionCurrent') {
            //{ seq: 0, total: 0, missionState: 0, missionMode: 0 }
            //console.log('MissionCurrent', data)
            this.set('seq', data.seq)
            //this.set('missionState', data.missionState)
        }
        else if (dataName == 'MissionCount') {
            // MissionCount {
            //     count: 10,
            //     targetSystem: 254,
            //     targetComponent: 1,
            //     missionType: 0
            //   }

        }
        else if (dataName == 'MissionItem') {
            // MissionItem {
            //     param1: 8,
            //     param2: 2000,
            //     param3: 0,
            //     param4: 0,
            //     x: 0,
            //     y: 0,
            //     z: 0,
            //     seq: 6,
            //     command: 183,
            //     targetSystem: 254,
            //     targetComponent: 1,
            //     frame: 0,
            //     current: 0,
            //     autocontinue: 1,
            //     missionType: 0
            //   }
        }
        else if (dataName == 'ParamValue') {
            // ParamValue {
            //     paramValue: 200,
            //     paramCount: 306,
            //     paramIndex: 281,
            //     paramId: 'GPSGLITCH_RADIUS',
            //     paramType: 9
            //   }

            //console.log(data);
            //console.log(data.paramIndex, data.paramId, data.paramValue);
        }
        else {
            console.log(data)
        }

    },

    addWaypoint: async function (wayPointData, cb) {
        let self = this
        let count = wayPointData.length

        await self.MissionCount(count, function (result) {
            let addEach = function (result) {
                let index = result.seq
                const wayPointObj = wayPointData[index];

                if (count == index + 1) {
                    //self.off('MissionRequest', addEach)
                    self.MissionItem(index, wayPointObj.cmd, wayPointObj.lat, wayPointObj.lon, wayPointObj.alt, wayPointObj.frame, wayPointObj.params,
                        function (result) {
                            setTimeout(() => {
                                self.MissionAck(0, function () {
                                    if (cb) cb(count)
                                })
                            }, 200);

                        }, true)

                } else {
                    self.MissionItem(index, wayPointObj.cmd, wayPointObj.lat, wayPointObj.lon, wayPointObj.alt, wayPointObj.frame, wayPointObj.params,
                        function (result) {
                            setTimeout(() => {
                                addEach(result)
                            }, 100);
                        })
                }
            }
            addEach(result)
            // self.on('MissionRequest', addEach)

            // for (let index = 0; index < wayPointData.length; index++) {
            //     await sleep(500)
            //   
            //     await this.MissionItem(index, wayPointObj.cmd, wayPointObj.lat, wayPointObj.lon, wayPointObj.alt, wayPointObj.frame)
            // }
            // await sleep(1000)
        })

    },

    //MAVLink protocol
    RequestDataStream: async function (enable) {
        //REQUEST_DATA_STREAM
        const message = new common.RequestDataStream();
        message.reqMessageRate = 10;
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.startStop = enable ? 1 : 0;
        // message.reqStreamId = 93
        await this.linkSend(message);
    },
    MissionClearAll: async function (cb) {
        let self = this
        const message = new common.MissionClearAll();
        message.targetSystem = 1;
        message.targetComponent = 1;

        await this.linkSend(message);

        this.qos('MissionAck', function () {
            self.linkSend(message);
        }, cb)
    },
    MissionAck: async function (type, cb) {
        let self = this
        const message = new common.MissionAck();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.type = type
        await self.linkSend(message);

        if (cb) cb()
        // this.qos('MissionAck', function () {
        //     self.linkSend( message);
        // }, cb)
    },
    MissionCount: async function (count, cb) {
        let self = this
        const message = new common.MissionCount();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.count = count
        await self.linkSend(message);

        this.qos('MissionRequest', function () {
            self.linkSend(message);
        }, cb)
    },

    qos: function (onMsg, repeatAct, cb) {
        let self = this;
        let ackTimeout = setInterval(() => {
            console.log('ackTimeout', onMsg);
            repeatAct()
        }, 100);

        self.once(onMsg, function (result) {
            clearInterval(ackTimeout)
            if (cb) cb(result)
        })
    },

    qosCmd: function (cmd, repeatAct, cb) {
        let self = this;

        let ackTimeout = setInterval(() => {
            console.log('ackCmdTimeout', cmd);
            repeatAct()
        }, 100);

        let onFunc = function (result) {
            if (result.command == cmd) {
                //console.log('SetMode', result);
                if (ackTimeout) clearInterval(ackTimeout)

                self.off('CommandAck', onFunc)
                if (cb) cb(result.result)
            }
        }
        self.on('CommandAck', onFunc)
    },

    MissionItem: async function (seq, cmd, x, y, z, frame, params, cb, isLast) {
        let self = this
        const message = new common.MissionItem();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.seq = seq;

        message.param1 = 0
        message.param2 = 0
        message.param3 = 0
        message.param4 = 0

        if (params) {
            for (const key in params) {
                if (Object.hasOwnProperty.call(params, key)) {
                    message[key] = params[key];
                }
            }
        }

        message.x = x
        message.y = y
        message.z = z
        message.command = cmd
        message.frame = frame
        message.current = 0
        message.autocontinue = 1
        message.missionType = 0

        //console.log('send', message);
        //await  node_mavlink.sendSigned(port, message)
        await self.linkSend(message);// new node_mavlink.MavLinkProtocolV2()

        if (isLast) {
            //console.log('isLast');
            this.qos('MissionAck', function () {
                self.linkSend(message);
            }, cb)
        } else {
            this.qos('MissionRequest', function () {
                self.linkSend(message);
            }, cb)
        }
    },

    MissionRequest: async function (seq, cb) {
        let self = this
        const message = new common.MissionRequest();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.seq = seq
        //message.missionType = 0
        //await  node_mavlink.sendSigned(port, message)
        await self.linkSend(message);// new node_mavlink.MavLinkProtocolV2()

        this.qos('MissionItem', function () {
            self.linkSend(message);
        }, cb)
    },

    MissionRequestList: async function (cb) {
        let self = this
        const message = new common.MissionRequestList();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.missionType = 0
        //await  node_mavlink.sendSigned(port, message)
        self.linkSend(message);// new node_mavlink.MavLinkProtocolV2()

        this.qos('MissionCount', function () {
            self.linkSend(message);
        }, cb)
    },
    MissionSetCurrent: async function (seq, cb) {
        let self = this
        const message = new common.MissionSetCurrent();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.seq = seq
        //await  node_mavlink.sendSigned(port, message)
        self.linkSend(message);// new node_mavlink.MavLinkProtocolV2()
    },

    ChangeOperatorControl: async function () {
        let self = this
        const message = new common.ChangeOperatorControl();
        message.targetSystem = 1;
        message.controlRequest = 0;
        message.passkey = "426"

        //await  node_mavlink.sendSigned(port, message)
        //console.log(message);
        await self.linkSend(message);// new node_mavlink.MavLinkProtocolV2()
    },
    ManualControl: async function (value) {
        let self = this
        const message = new common.ManualControl();

        message.target = 1;

        message.z = value

        //await  node_mavlink.sendSigned(port, message)
        //console.log(message);
        await self.linkSend(message);// new node_mavlink.MavLinkProtocolV2()
    },
    RcChannelsOverrideZero: async function (params) {
        let self = this
        const message = new common.RcChannelsOverride();

        message.targetSystem = 1;
        message.targetComponent = 1;

        message.chan1Raw = 0
        message.chan2Raw = 0
        message.chan3Raw = 0
        message.chan4Raw = 0
        message.chan5Raw = 0
        message.chan6Raw = 0
        message.chan7Raw = 0
        message.chan8Raw = 0

        if (params) {
            for (const key in params) {
                if (Object.hasOwnProperty.call(params, key)) {
                    message[key] = params[key];
                }
            }
        }
        //await  node_mavlink.sendSigned(port, message)
        //console.log(message);
        await self.linkSend(message);// new node_mavlink.MavLinkProtocolV2()
    },

    RcChannelsOverride: async function (params) {
        let self = this
        const message = new common.RcChannelsOverride();

        message.targetSystem = 1;
        message.targetComponent = 1;

        message.chan1Raw = 1500
        message.chan2Raw = 1500
        message.chan3Raw = 1000
        message.chan4Raw = 1500
        message.chan5Raw = 1000
        message.chan6Raw = 1500
        message.chan7Raw = 1500
        message.chan8Raw = 1500

        if (params) {
            for (const key in params) {
                if (Object.hasOwnProperty.call(params, key)) {
                    message[key] = params[key];
                }
            }
        }
        //await  node_mavlink.sendSigned(port, message)
        //console.log(message);
        await self.linkSend(message);// new node_mavlink.MavLinkProtocolV2()
    },

    MissionStart: async function (start, end) { // it just set mode to auto
        let self = this
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.MISSION_START
        msg.targetSystem = 1;
        msg.targetComponent = 1;
        // msg.param1 = start
        // msg.param2 = end
        await self.linkSend(msg);
    },

    SetMode: async function (mode, cb) {
        let self = this
        const message = new common.SetMode();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.customMode = mode
        message.baseMode = 1
        //.log();
        await self.linkSend(message);

        // let setmodeCallback = (result) => {
        //     if (result.command == 11) {
        //         //console.log('SetMode', result);
        //         this.off('CommandAck', setmodeCallback)
        //         if (cb) cb(result.result)
        //     }
        // }
        // this.on('CommandAck', setmodeCallback)

        this.qosCmd(11, function () {
            self.linkSend(message);
        }, cb)
    },

    Arming: async function (enable, cb) {
        let self = this
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.COMPONENT_ARM_DISARM
        msg.targetSystem = 1;
        msg.targetComponent = 1;

        msg.param1 = enable ? 1 : 0
        //msg.param2 = 1
        await self.linkSend(msg)
        // let setmodeCallback = (result) => {
        //     if (result.command == 400) {
        //         //console.log('SetMode', result);
        //         this.off('CommandAck', setmodeCallback)
        //         if (cb) cb(result.result)
        //     }
        // }
        // this.on('CommandAck', setmodeCallback)
        this.qosCmd(msg.command, function () {
            self.linkSend(msg);
        }, cb)
    },

    doSetServo: async function (pin, pwm, cb) {
        let self = this
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.DO_SET_SERVO
        msg.targetSystem = 1;
        msg.targetComponent = 1;

        msg.param1 = pin;
        msg.param2 = pwm;
        await self.linkSend(msg);
        // let setmodeCallback = (result) => {
        //     if (result.command == 183) {
        //         //console.log('SetMode', result);
        //         this.off('CommandAck', setmodeCallback)
        //         if (cb) cb(result.result)
        //     }
        // }
        // this.on('CommandAck', setmodeCallback)

        this.qosCmd(msg.command, function () {
            self.linkSend(msg);
        }, cb)
    },

    getAllMission: async function (cb) {
        let self = this
        self.MissionRequestList(function (result) {
            //console.log('MissionRequestList', result);
            async.timesSeries(result.count, function (n, next) {

                setTimeout(() => {
                    //console.log('MissionRequest', n);
                    self.MissionRequest(n, function (wp) {
                        //console.log(wp);
                        next(null, wp);
                    })
                }, 50);


            }, function (err, wps) {
                cb(wps)
            });


        })
    },
    getParamRequestList: function () {
        let self = this
        const msg = new common.ParamRequestList()
        msg.targetSystem = 1
        msg.targetComponent = 1

        self.linkSend(msg);
    },
    ParamRequestRead: function (paramId, paramIndex, cb) {
        let self = this
        const msg = new common.ParamRequestRead()
        msg.targetSystem = 1
        msg.targetComponent = 1

        msg.paramId = paramId
        msg.paramIndex = paramIndex
        self.linkSend(msg);
        // this.qosCmd(20, function () {
        //     linkSend( msg);
        // }, cb)

        this.qos('ParamValue', function () {
            self.linkSend(msg);
        }, cb)
    },
    ParamSet: function (paramId, paramValue, cb) {
        let self = this
        const msg = new common.ParamSet()
        msg.targetSystem = 1
        msg.targetComponent = 1

        msg.paramId = paramId
        //msg.paramIndex = paramIndex
        //msg.paramType = 9
        msg.paramValue = paramValue
        self.linkSend(msg);
        // this.qosCmd(20, function () {
        //     self.linkSend( msg);
        // }, cb)

        this.qos('ParamValue', function () {
            self.linkSend(msg);
        }, cb)
    },
    ParamSetList: function (paraamList, cb) {
        let self = this
        let result = []
        //console.log(paraamList);
        async.eachSeries(
            paraamList,
            function (para, callback) {
                self.ParamSet(para[0], para[1], function (data) {
                    //console.log(data);
                    result.push({ paramId: data.paramId, paramValue: data.paramValue })
                    callback(null);
                })

            }, function (err) {
                // console.log('result', result);
                if (cb) cb(result)
            })
    },

    setRateValues: function (changeData, cb) {
        let self = this
        let setParamList = []
        // if (PID.P !== undefined) {
        //     setParamList.push(['RATE_RLL_P', PID.P])
        //     setParamList.push(['RATE_PIT_P', PID.P])
        // }

        // if (PID.I !== undefined) {
        //     setParamList.push(['RATE_RLL_I', PID.I])
        //     setParamList.push(['RATE_PIT_I', PID.I])
        // }

        // if (PID.D !== undefined) {
        //     setParamList.push(['RATE_RLL_D', PID.D])
        //     setParamList.push(['RATE_PIT_D', PID.D])
        // }

        for (const key in changeData) {
            if (Object.hasOwnProperty.call(changeData, key)) {
                const value = changeData[key];
                setParamList.push([key, value])
            }
        }

        link.ParamSetList(setParamList, function (result) {
            //console.log(result);
            if (cb) cb(result)
        })
    },
    getRateValues: function (cb) {
        let self = this
        let result = []
        async.eachSeries(
            [
                [119, 'RATE_RLL_P'],
                [120, 'RATE_RLL_I'],
                [121, 'RATE_RLL_D'],
                [123, 'RATE_PIT_P'],
                [124, 'RATE_PIT_I'],
                [125, 'RATE_PIT_D'],

                [152, 'STB_RLL_P'],
                [153, 'STB_PIT_P'],

                // [140, 'THR_ACCEL_P'],
                // [141, 'THR_ACCEL_I'],
                // [142, 'THR_ACCEL_D'],
            ],
            function (para, callback) {
                //console.log(para);
                self.ParamRequestRead(para[1], para[0], function (data) {
                    //console.log(data);
                    result.push({ paramId: data.paramId, paramValue: data.paramValue })
                    callback(null);
                })

            }, function (err) {
                // console.log('result', result);
                if (cb) cb(result)
            })
    },
    getBattMult: function (cb) {
        // 259 BATT_MONITOR 4
        // 260 BATT_VOLT_PIN 13
        // 261 BATT_CURR_PIN 12
        // 262 BATT_VOLT_MULT 10.399999618530273
        // 263 BATT_AMP_PERVOLT 17
        // 264 BATT_AMP_OFFSET 0
        // 265 BATT_CAPACITY 3300
        // 266 BATT_VOLT2_PIN -1
        // 267 BATT_VOLT2_MULT 1
        this.ParamRequestRead('BATT_VOLT_MULT', 262, cb)
    },
    setBattMult: function (val, cb) {
        this.ParamSet('BATT_VOLT_MULT', val, cb)
    },

    setConditionYaw: async function (targetAngle, speedDuringChange, cb) {
        let self = this
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.CONDITION_YAW
        msg.targetSystem = 1;
        msg.targetComponent = 1;

        msg.param1 = targetAngle;//[0-360]
        msg.param2 = speedDuringChange; //[deg per second]
        msg.param3 = 0; // direction (-1:ccw, +1:cw)
        msg.param4 = 0; //  relative offset (1) or absolute angle (0)

        //console.log('setConditionYaw', msg);
        await self.linkSend(msg);
        // let setmodeCallback = (result) => {
        //     if (result.command == 183) {
        //         //console.log('SetMode', result);
        //         this.off('CommandAck', setmodeCallback)
        //         if (cb) cb(result.result)
        //     }
        // }
        // this.on('CommandAck', setmodeCallback)

        this.qosCmd(msg.command, function () {
            self.linkSend(msg);
        }, cb)
    },

    navTakeoff: async function (alt, cb) {
        let self = this
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.NAV_TAKEOFF
        msg.targetSystem = 1;
        msg.targetComponent = 1;

        msg.param7 = alt;

        await self.linkSend(msg);
        // let setmodeCallback = (result) => {
        //     if (result.command == 22) {
        //         //console.log('SetMode', result);
        //         this.off('CommandAck', setmodeCallback)
        //         if (cb) cb(result.result)
        //     }
        // }
        // this.on('CommandAck', setmodeCallback)

        this.qosCmd(msg.command, function () {
            self.linkSend(msg);
        }, cb)
    },

    guidedWP: async function (alt, lat, lon, cb) {
        this.MissionItemGuidedRequest(16, lat, lon, alt, 3, null, cb, 2)
    },

    // case MAV_CMD_NAV_VELOCITY:                          // MAV ID: 91
    // cmd.p1 = packet.param1;                         // frame - unused
    // cmd.content.nav_velocity.x = packet.x;          // lat (i.e. north) velocity in m/s
    // cmd.content.nav_velocity.y = packet.y;          // lon (i.e. east) velocity in m/s
    // cmd.content.nav_velocity.z = packet.z;          // vertical (i.e. up) velocity in m/s

    guidedVelocity: async function (vertical, lat, lon, cb) {
        this.MissionItemGuidedRequest(92, lat, lon, vertical, 3, { param1: 3 }, cb, 2)
    },

    // guidedChangeAlt: async function (alt, cb) {
    //     this.MissionItemGuidedRequest(16, 0, 0, alt, 3, null, cb, 3)
    // },

    MissionItemGuidedRequest: async function (cmd, x, y, z, frame, params, cb, current) {
        let self = this
        const message = new common.MissionItem();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.seq = 0;

        message.param1 = 0
        message.param2 = 0
        message.param3 = 0
        message.param4 = 0

        if (params) {
            for (const key in params) {
                if (Object.hasOwnProperty.call(params, key)) {
                    message[key] = params[key];
                }
            }
        }

        message.x = x
        message.y = y
        message.z = z
        message.command = cmd
        message.frame = frame
        message.current = current ? current : 2 // 2 for guild mode 3 for change alt only
        message.autocontinue = 1
        message.missionType = 0

        //console.log('send', message);
        //await  node_mavlink.sendSigned(port, message)
        await self.linkSend(message);// new node_mavlink.MavLinkProtocolV2()

        // if (isLast) {
        //     //console.log('isLast');
        this.qos('MissionAck', function () {
            self.linkSend(message);
        }, cb)
        // } else {
        //     this.qos('MissionRequest', function () {
        //         linkSend( message);
        //     }, cb)
        // }
    },
    setRallyPoint: async function () {

    },
    getRallyPoint: async function () {

        let self = this
        const message = new common.RallyFetchPoint();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.idx = 0.

        await self.linkSend(message);// new node_mavlink.MavLinkProtocolV2()

        // this.qos('MissionAck', function () {
        //     self.linkSend(message);
        // }, cb)
    }
})

let link = module.exports = new MvLink()

// conn.on('Heartbeat', function (data) {
//     console.log(data);
// })

// waitFor(function (result) {
//     // console.log('waitFor', result);

// })

async function main() {
    console.log('main');
    setTimeout(() => {

        // link.getRateValues(function (result) {
        //     console.log(result);
        //     // link.setRateValues({ P: 0.12 }, function (result) {
        //     //     console.log(result);
        //     // })

        // })
        // link.getParamRequestList(function (result) {
        //     console.log(result);
        // })
        // link.getBattMult(function (result) {
        //     console.log(result);
        // })

        // link.setBattMult(9.85, function (result) {
        //     console.log(result);
        // })
        // link.setRateValues({ P: 0.12 }, function (result) {
        // })
        // link.ParamSetList([['RATE_RLL_P', 0.11], ['RATE_PIT_P', 0.11]], function (result) {
        //     console.log(result);
        // })

    }, 1000);
    //  await waitFor(() => online)

    //3:auto
    //0: "Stabilize",
    //16: "PosHold",

    // setTimeout(() => {

    // }, 10);

    // link.getAllMission(function (wps) {
    //     console.log(wps.length);
    // });

    //link.MissionCount(1)

    // link.once('Heartbeat', function (params) {
    //     console.log('arming');
    //     // setTimeout(() => {

    //link.SetMode(0)
    //     //     //sleep(2000)

    //     //     // }, 1000);
    //     // })
    // })

    setTimeout(function () {
        link.RequestDataStream(true)
    }, 5000)


    // link.ChangeOperatorControl()
    // setTimeout(() => {
    //     //link.RcChannelsOverride(1000)
    //     link.RcChannelsOverride({ chan3Raw: 976 })
    // }, 2000);
    // setTimeout(() => {
    //     console.log('start arm');
    //     link.Arming(1)
    // }, 2000);


    // setInterval(() => {
    //     // link.MissionRequestList(function (result) {
    //     //     console.log(result);
    //     // })
    //     //link.SetMode(0)
    //     link.RcChannelsOverride({ chan3Raw: 1000 })
    // }, 1000);


    // await link.addWaypoint([
    //     waypointGen.waypoint(0, 8.6970325, 98.2410939),
    //     waypointGen.takeoff(20),
    //     waypointGen.waypoint(20, 8.6970391, 98.2411844,),
    //     waypointGen.landing(1, 8.69697420, 98.24110060)
    // ])

    // conn.MissionRequest(0, function (result) {
    //     console.log('result', result);
    // })
    //console.log(1.5 * 1e7);

    // setInterval(() => {
    //     link.doSetServo(13, 1200)
    // }, 1000);

    // setTimeout(() => {
    //     //link.MissionSetCurrent(5)
    //     link.MissionClearAll(function () {
    //         console.log('clear');
    //     })
    // }, 5000);
}

//let wayPointData = []

main()