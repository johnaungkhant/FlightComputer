const Backbone = require("backbone");
const async = require("async");

//import { SerialPort } from 'serialport'
const SerialPort = require("serialport").SerialPort;

//import { MavLinkPacketSplitter, MavLinkPacketParser } from 'node-mavlink'
const node_mavlink = require('node-mavlink');
const MavLinkPacketSplitter = node_mavlink.MavLinkPacketSplitter;
const MavLinkPacketParser = node_mavlink.MavLinkPacketParser;
const minimal = node_mavlink.minimal;
const common = node_mavlink.common;
const ardupilotmega = node_mavlink.ardupilotmega;
const waitFor = node_mavlink.waitFor;
const sleep = node_mavlink.sleep;
const MavLinkProtocolV1 = node_mavlink.MavLinkProtocolV1;

//import { MavLinkPacketSplitter, MavLinkPacketParser, minimal, common, ardupilotmega } from 'node-mavlink';
// create a registry of mappings between a message id and a data class
const REGISTRY = Object.assign(Object.assign(Object.assign({}, minimal.REGISTRY), common.REGISTRY), ardupilotmega.REGISTRY);

//for udp proxy
// require("./runMAVProxy.js")
// const reader = port = new node_mavlink.MavEsp8266()
// reader.start()
// MavLinkPacket = node_mavlink.MavLinkPacket
// const linkSend = function (port, cmd) {
//     port.send(cmd)
// }

//let serialPortPath = '/dev/ttyS2'; //for orange pi i96
//let serialPortPath = '/dev/ttyS1'; //for orange pi //armbian
//let serialPortPath = '/dev/ttyS3'; //for banana pi //armbian
//let serialPortPath = 'COM23';
//let serialPortPath = '/dev/serial0'; //for raspberry pi
let serialPortPath = '/dev/ttyMSM0';

const port = new SerialPort({ path: serialPortPath, baudRate: 115200 });//115200

const reader = port
    .pipe(new MavLinkPacketSplitter())
    .pipe(new MavLinkPacketParser())


node_mavlink.MavLinkProtocol.SYS_ID = 255


let seq = 0;
/**
 * Send a packet to the stream
 *
 * @param stream Stream to send the data to
 * @param msg message to serialize and send
 * @param protocol protocol to use (default: MavLinkProtocolV1)
 * @returns number of bytes sent
 */
async function send(stream, msg, protocol = new MavLinkProtocolV1()) {
    return new Promise((resolve, reject) => {
        //console.log(msg);
        const buffer = protocol.serialize(msg, seq++);
        //let base64Str = buffer.toString('base64')
        // console.log(buffer);
        // console.log(Buffer.from(base64Str, 'base64'));

        //let u8array = Uint8Array.from(buffer);
        //console.log(u8array.toLocaleString());

        // console.log(buffer.toString('hex'));
        // console.log(buffer.toString('utf8'));
        // console.log(buffer.toString());

        seq &= 255;
        stream.write(buffer, err => {
            if (err)
                reject(err);
            else
                resolve(buffer.length);
        });
    });
}

const linkSend = send// node_mavlink.send

let waypointGen = {
    takeoff: function (alt) {
        return { cmd: 22, lat: 0, lon: 0, alt: alt, frame: 3 }
    },
    waypoint: function (alt, lat, lon) {
        return { cmd: 16, lat: lat, lon: lon, alt: alt, frame: 3 }
    },
    landing: function (alt, lat, lon) {
        return { cmd: 21, lat: lat, lon: lon, alt: alt, frame: 3 }
    }
}

let MvLink = Backbone.Model.extend({

    defaults: {

    },
    online: false,
    initialize: function () {
        let self = this
        // constructing a reader that will emit each packet separately

        reader.on('data', packet => {
            try {
                this.online = true
                const clazz = REGISTRY[packet.header.msgid];
                if (clazz) {
                    const data = packet.protocol.data(packet.payload, clazz);
                    //console.log(data);
                    this.trigger(data.constructor.name, data)
                    self.processData(data);
                } else {
                    console.log(packet);
                }
            } catch (error) {
                console.log('err', error);
            }

        })
    },

    processData: function (data) {

        const dataName = data.constructor.name;

        if (dataName == "Heartbeat") {

            // Heartbeat Heartbeat {
            //     customMode: 3,
            //     type: 2,
            //     autopilot: 3,
            //     baseMode: 89,
            //     systemStatus: 3,
            //     mavlinkVersion: 3
            //   }

            //console.log('Heartbeat', data)
            //console.log(data.customMode);
            this.set('customMode', data.customMode)
            this.set('baseMode', data.baseMode)

        } else if (dataName == 'StatusText') {
            console.log(data);
        } else if (dataName == 'GlobalPositionInt') {
            // GlobalPositionInt {
            //     timeBootMs: 741590,
            //     lat: 0,
            //     lon: 0,
            //     alt: -17000,
            //     relativeAlt: -1440,
            //     vx: 0,
            //     vy: 0,
            //     vz: 0,
            //     hdg: 30586
            //   }
            this.set('posInt', { lat: data.lat, lon: data.lon })
            this.set('alt', data.alt)
            this.set('relativeAlt', data.relativeAlt)

            //console.log(data);
        }
        else if (dataName == 'GpsRawInt') {
            // GpsRawInt {
            //     timeUsec: 0n,
            //     lat: 0,
            //     lon: 0,
            //     alt: -17000,
            //     eph: 9999,
            //     epv: 65535,
            //     vel: 0,
            //     cog: 0,
            //     fixType: 1,
            //     satellitesVisible: 0,
            //     altEllipsoid: 0,
            //     hAcc: 0,
            //     vAcc: 0,
            //     velAcc: 0,
            //     hdgAcc: 0,
            //     yaw: 0
            //   }
            this.set('posRawInt', { lat: data.lat, lon: data.lon })
            this.set('hdop', data.eph)
            //this.set('timeUsec', data.timeUsec)

            //console.log(data);
            //console.log('pos', { lat: data.lat, lon: data.lon });
        } else if (dataName == 'ScaledPressure') {
            // ScaledPressure {
            //     timeBootMs: 1572789,
            //     pressAbs: 1010.278564453125,
            //     pressDiff: 0.3246093690395355,
            //     temperature: 3597,
            //     temperaturePressDiff: 0
            //   }

            //console.log(data);
        } else if (dataName == 'VfrHud') {
            //airspeed, m/s
            //groundspeed, m/s
            //alt, m
            //climb, m/s
            //heading, deg
            //throttle %

            this.set(data)
        } else if (dataName == 'NavControllerOutput') {
            // NavControllerOutput {
            //     navRoll: 0,
            //     navPitch: 0,
            //     altError: 0,
            //     aspdError: 0,
            //     xtrackError: 0,
            //     navBearing: 305,
            //     targetBearing: 0,
            //     wpDist: 0
            //   }

            //console.log(data);
            this.set('wpDist', data.wpDist)
        }
        else if (dataName == 'ServoOutputRaw') {
            // ServoOutputRaw {
            //     timeUsec: 1572810088,
            //     servo1Raw: 999,
            //     servo2Raw: 999,
            //     servo3Raw: 999,
            //     servo4Raw: 999,
            //     servo5Raw: 32767,
            //     servo6Raw: 32767,
            //     servo7Raw: 32767,
            //     servo8Raw: 1000,
            //     port: 0,
            //     servo9Raw: 0,
            //     servo10Raw: 0,
            //     servo11Raw: 0,
            //     servo12Raw: 0,
            //     servo13Raw: 0,
            //     servo14Raw: 0,
            //     servo15Raw: 0,
            //     servo16Raw: 0
            //   }
            //this.set('servo8Raw', data.servo8Raw)
            //console.log(data);
        }
        else if (dataName == 'Attitude') {
            // Attitude {
            //     timeBootMs: 1572810,
            //     roll: 0.036526355892419815,
            //     pitch: -0.033109262585639954,
            //     yaw: -0.9457555413246155,
            //     rollspeed: -0.0020592641085386276,
            //     pitchspeed: -0.0035544950515031815,
            //     yawspeed: -0.00021284446120262146
            //   }
            this.set('roll', data.roll)
            this.set('pitch', data.pitch)
            this.set('yaw', data.yaw)
            //console.log(data);
        }
        else if (dataName == 'RawImu') {
            // RawImu {
            //     timeUsec: 741559655n,
            //     xacc: -7,
            //     yacc: 18,
            //     zacc: -998,
            //     xgyro: 0,
            //     ygyro: -4,
            //     zgyro: -1,
            //     xmag: 156,
            //     ymag: 212,
            //     zmag: 34,
            //     id: 0,
            //     temperature: 0
            //   }
        }
        else if (dataName == 'RcChannelsRaw') {
            // RcChannelsRaw {
            //     timeBootMs: 741469,
            //     chan1Raw: 1501,
            //     chan2Raw: 1500,
            //     chan3Raw: 900,
            //     chan4Raw: 1500,
            //     chan5Raw: 1555,
            //     chan6Raw: 1499,
            //     chan7Raw: 1499,
            //     chan8Raw: 1500,
            //     port: 0,
            //     rssi: 0
            //   }
            //console.log(data.chan3Raw);
        }
        else if (dataName == 'Ahrs') {
            // Ahrs {
            //     omegaIx: 0.0013206477742642164,
            //     omegaIy: 0.0034318475518375635,
            //     omegaIz: 0.00027965992921963334,
            //     accelWeight: 0,
            //     renormVal: 0,
            //     errorRp: 0.0009030818473547697,
            //     errorYaw: 0.017257610335946083
            //   }
        }
        else if (dataName == 'SensorOffsets') {
            // SensorOffsets {
            //     magDeclination: 0,
            //     rawPress: 101007,
            //     rawTemp: 3485,
            //     gyroCalX: 0.011637239716947079,
            //     gyroCalY: -0.011344578117132187,
            //     gyroCalZ: -0.014686228707432747,
            //     accelCalX: 0.11140401661396027,
            //     accelCalY: 0.057300176471471786,
            //     accelCalZ: 0.5820214748382568,
            //     magOfsX: 143,
            //     magOfsY: -8,
            //     magOfsZ: 112
            //   }
        } else if (dataName == 'SysStatus') {
            // SysStatus {
            //     onboardControlSensorsPresent: 2227247,
            //     onboardControlSensorsEnabled: 2227247,
            //     onboardControlSensorsHealth: 2227247,
            //     load: 718,
            //     voltageBattery: 0,
            //     currentBattery: -1,
            //     dropRateComm: 0,
            //     errorsComm: 0,
            //     errorsCount1: 0,
            //     errorsCount2: 0,
            //     errorsCount3: 0,
            //     errorsCount4: 0,
            //     batteryRemaining: -1,
            //     onboardControlSensorsPresentExtended: 0,
            //     onboardControlSensorsEnabledExtended: 0,
            //     onboardControlSensorsHealthExtended: 0
            //   }
            this.set('voltageBattery', data.voltageBattery)
            this.set('currentBattery', data.currentBattery)
            this.set('batteryRemaining', data.batteryRemaining)

            //console.log('voltageBattery', data.voltageBattery / 1000, data.batteryRemaining,data.currentBattery);
        }
        else if (dataName == 'MemInfo') {
            // MemInfo { brkval: 7175, freemem: 989, freemem32: 0 }
        }
        else if (dataName == 'HwStatus') {
            //HwStatus { Vcc: 4693, I2Cerr: 0 }
        }
        else if (dataName == 'SystemTime') {
            //SystemTime { timeUnixUsec: 0n, timeBootMs: 1572830 }
            this.set('timeUnixUsec', data.timeUnixUsec)
            //console.log(data);
        }
        else if (dataName == 'MissionAck') {
            if (data.result != 0) console.log(data)

            console.log(data)
        }
        else if (dataName == 'CommandAck') {
            if (data.result != 0) console.log(data)

            console.log(data)
        }
        else if (dataName == 'MissionRequest') {

            console.log(data)
        }
        else if (dataName == 'MissionCurrent') {
            //{ seq: 0, total: 0, missionState: 0, missionMode: 0 }
            //console.log(data)
            this.set('seq', data.seq)
            //this.set('missionState', data.missionState)
        }
        else if (dataName == 'MissionCount') {
            // MissionCount {
            //     count: 10,
            //     targetSystem: 254,
            //     targetComponent: 1,
            //     missionType: 0
            //   }

        }
        else if (dataName == 'MissionItem') {
            // MissionItem {
            //     param1: 8,
            //     param2: 2000,
            //     param3: 0,
            //     param4: 0,
            //     x: 0,
            //     y: 0,
            //     z: 0,
            //     seq: 6,
            //     command: 183,
            //     targetSystem: 254,
            //     targetComponent: 1,
            //     frame: 0,
            //     current: 0,
            //     autocontinue: 1,
            //     missionType: 0
            //   }
        }
        else {
            console.log(data)
        }

    },

    addWaypoint: async function (wayPointData, cb) {
        let self = this
        let count = wayPointData.length
        await self.MissionCount(count)

        let addEach = function (result) {
            let index = result.seq
            const wayPointObj = wayPointData[index];
            self.MissionItem(index, wayPointObj.cmd, wayPointObj.lat, wayPointObj.lon, wayPointObj.alt, wayPointObj.frame, wayPointObj.params)

            if (count == index + 1) {
                self.off('MissionRequest', addEach)
                self.MissionAck(0)
                if (cb) cb(count)
            }
        }
        self.on('MissionRequest', addEach)
        // for (let index = 0; index < wayPointData.length; index++) {
        //     await sleep(500)
        //   
        //     await this.MissionItem(index, wayPointObj.cmd, wayPointObj.lat, wayPointObj.lon, wayPointObj.alt, wayPointObj.frame)
        // }
        // await sleep(1000)

    },

    //MAVLink protocol
    RequestDataStream: async function (enable) {
        //REQUEST_DATA_STREAM
        const message = new common.RequestDataStream();
        message.reqMessageRate = 10;
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.startStop = enable ? 1 : 0;
        // message.reqStreamId = 93
        await linkSend(port, message);
    },
    MissionClearAll: async function () {

        const message = new common.MissionClearAll();
        message.targetSystem = 1;
        message.targetComponent = 1;

        await linkSend(port, message);
    },
    MissionAck: async function (type) {

        const message = new common.MissionAck();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.type = type
        await linkSend(port, message);
    },
    MissionCount: async function (count) {

        const message = new common.MissionCount();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.count = count
        await linkSend(port, message);
    },

    MissionItem: async function (seq, cmd, x, y, z, frame, params) {

        const message = new common.MissionItem();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.seq = seq;

        message.param1 = 0
        message.param2 = 0
        message.param3 = 0
        message.param4 = 0

        if (params) {
            for (const key in params) {
                if (Object.hasOwnProperty.call(params, key)) {
                    message[key] = params[key];
                }
            }
        }

        message.x = x
        message.y = y
        message.z = z
        message.command = cmd
        message.frame = frame
        message.current = 0
        message.autocontinue = 1
        message.missionType = 0

        //console.log('send', message);
        //await  node_mavlink.sendSigned(port, message)
        await linkSend(port, message);// new node_mavlink.MavLinkProtocolV2()
    },

    MissionRequest: async function (seq, cb) {

        const message = new common.MissionRequest();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.seq = seq
        //message.missionType = 0
        //await  node_mavlink.sendSigned(port, message)
        await linkSend(port, message);// new node_mavlink.MavLinkProtocolV2()
        this.once('MissionItem', function (data) {
            if (cb) cb(data)
        })
    },

    MissionRequestList: async function (cb) {

        const message = new common.MissionRequestList();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.missionType = 0
        //await  node_mavlink.sendSigned(port, message)
        await linkSend(port, message);// new node_mavlink.MavLinkProtocolV2()

        this.once('MissionCount', cb)
    },

    ChangeOperatorControl: async function () {
        const message = new common.ChangeOperatorControl();
        message.targetSystem = 1;
        message.controlRequest = 0;
        message.passkey = "426"

        //await  node_mavlink.sendSigned(port, message)
        //console.log(message);
        await linkSend(port, message);// new node_mavlink.MavLinkProtocolV2()
    },
    ManualControl: async function (value) {
        const message = new common.ManualControl();

        message.target = 1;

        message.z = value

        //await  node_mavlink.sendSigned(port, message)
        //console.log(message);
        await linkSend(port, message);// new node_mavlink.MavLinkProtocolV2()
    },
    RcChannelsOverride: async function (params) {
        const message = new common.RcChannelsOverride();

        message.targetSystem = 1;
        message.targetComponent = 1;

        message.chan1Raw = 1500
        message.chan2Raw = 1500
        message.chan3Raw = 1000
        message.chan4Raw = 1500
        message.chan5Raw = 1000
        message.chan6Raw = 1500
        message.chan7Raw = 1500
        message.chan8Raw = 1500

        if (params) {
            for (const key in params) {
                if (Object.hasOwnProperty.call(params, key)) {
                    message[key] = params[key];
                }
            }
        }
        //await  node_mavlink.sendSigned(port, message)
        //console.log(message);
        await linkSend(port, message);// new node_mavlink.MavLinkProtocolV2()

    },
    MissionStart: async function (start, end) { // it just set mode to auto
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.MISSION_START
        msg.targetSystem = 1;
        msg.targetComponent = 1;
        // msg.param1 = start
        // msg.param2 = end
        await linkSend(port, msg);
    },

    SetMode: async function (mode, cb) {

        const message = new common.SetMode();
        message.targetSystem = 1;
        message.targetComponent = 1;
        message.customMode = mode
        message.baseMode = 1
        //.log();
        await linkSend(port, message);

        let setmodeCallback = (result) => {
            if (result.command == 11) {
                //console.log('SetMode', result);
                this.off('CommandAck', setmodeCallback)
                if (cb) cb(result.result)
            }
        }
        this.on('CommandAck', setmodeCallback)
    },

    Arming: async function (enable, cb) {
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.COMPONENT_ARM_DISARM
        msg.targetSystem = 1;
        msg.targetComponent = 1;

        msg.param1 = enable ? 1 : 0
        //msg.param2 = 1
        await linkSend(port, msg)
        let setmodeCallback = (result) => {
            if (result.command == 400) {
                //console.log('SetMode', result);
                this.off('CommandAck', setmodeCallback)
                if (cb) cb(result.result)
            }
        }
        this.on('CommandAck', setmodeCallback)
    },

    doSetServo: async function (pin, pwm, cb) {
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.DO_SET_SERVO
        msg.targetSystem = 1;
        msg.targetComponent = 0;

        msg.param1 = pin;
        msg.param2 = pwm;
        await linkSend(port, msg);
        let setmodeCallback = (result) => {
            if (result.command == 183) {
                //console.log('SetMode', result);
                this.off('CommandAck', setmodeCallback)
                if (cb) cb(result.result)
            }
        }
        this.on('CommandAck', setmodeCallback)
    },
    navTakeoff: async function (alt, cb) {
        //SET_MESSAGE_INTERVAL 
        // Create an instance of of the `CommandInt` class that will be the vessel
        // for containing the command data
        const msg = new common.CommandLong()
        msg.command = common.MavCmd.NAV_TAKEOFF
        msg.targetSystem = 1;
        msg.targetComponent = 1;

        msg.param7 = alt;

        await linkSend(port, msg);
        let setmodeCallback = (result) => {
            if (result.command == 22) {
                //console.log('SetMode', result);
                this.off('CommandAck', setmodeCallback)
                if (cb) cb(result.result)
            }
        }
        this.on('CommandAck', setmodeCallback)
    },
    getAllMission: async function (cb) {
        let self = this
        self.MissionRequestList(function (result) {
            //console.log(result);
            async.timesSeries(result.count, function (n, next) {

                self.MissionRequest(n, function (wp) {
                    //console.log(wp);
                    next(null, wp);
                })

            }, function (err, wps) {
                cb(wps)
            });


        })
    }
})

let link = module.exports = new MvLink()

// conn.on('Heartbeat', function (data) {
//     console.log(data);
// })



// waitFor(function (result) {
//     // console.log('waitFor', result);

// })

async function main() {
    //  await waitFor(() => online)

    //3:auto
    //0: "Stabilize",
    //16: "PosHold",

    // link.getAllMission(function (wps) {
    //     console.log(wps);
    // });

    //link.MissionCount(1)


    // link.once('Heartbeat', function (params) {
    //     console.log('arming');
    //     // setTimeout(() => {

    //link.SetMode(0)
    //     //     //sleep(2000)

    //     //     // }, 1000);
    //     // })
    // })

    link.RequestDataStream(false)

    // link.ChangeOperatorControl()
    // setTimeout(() => {
    //     link.RcChannelsOverride(1000)
    // }, 2000);
    // link.Arming(1)

    setInterval(() => {
        // link.MissionRequestList(function (result) {
        //     console.log(result);
        // })
        // link.SetMode(0)
    }, 1000);


    //link.RcChannelsOverride({ chan3Raw: 976 })

    // await link.addWaypoint([
    //     waypointGen.waypoint(0, 8.6970325, 98.2410939),
    //     waypointGen.takeoff(20),
    //     waypointGen.waypoint(20, 8.6970391, 98.2411844,),
    //     waypointGen.landing(1, 8.69697420, 98.24110060)
    // ])

    // conn.MissionRequest(0, function (result) {
    //     console.log('result', result);
    // })
    //console.log(1.5 * 1e7);

    setInterval(() => {
        link.doSetServo(13, 1200)
    }, 1000);
}

//let wayPointData = []

//main()